<?php
require_once 'config.php';

class WebScraper {
    private $userAgent;
    private $timeout;
    
    public function __construct() {
        $this->userAgent = USER_AGENT;
        $this->timeout = SCRAPING_TIMEOUT;
    }
    
    /**
     * Fetch stock data from Yahoo Finance
     */
    public function getStockData($symbol) {
        try {
            // Try multiple sources for better coverage
            
            // 1. Try Yahoo Finance with .NS suffix for Indian stocks
            $url = "https://query1.finance.yahoo.com/v8/finance/chart/{$symbol}.NS";
            $json = $this->fetchUrl($url);
            
            if ($json) {
                $data = json_decode($json, true);
                if ($data && isset($data['chart']['result'][0])) {
                    return $this->parseYahooChartData($data, $symbol);
                }
            }
            
            // 2. Try Yahoo Finance without suffix (for US stocks)
            $url = "https://query1.finance.yahoo.com/v8/finance/chart/{$symbol}";
            $json = $this->fetchUrl($url);
            
            if ($json) {
                $data = json_decode($json, true);
                if ($data && isset($data['chart']['result'][0])) {
                    return $this->parseYahooChartData($data, $symbol);
                }
            }
            
            // 3. Try Yahoo Finance with .BO suffix for BSE stocks
            $url = "https://query1.finance.yahoo.com/v8/finance/chart/{$symbol}.BO";
            $json = $this->fetchUrl($url);
            
            if ($json) {
                $data = json_decode($json, true);
                if ($data && isset($data['chart']['result'][0])) {
                    return $this->parseYahooChartData($data, $symbol);
                }
            }
            
            // 4. Try MoneyControl for Indian stocks
            if (strlen($symbol) > 3) {
                $moneyControlData = $this->getMoneyControlData($symbol);
                if ($moneyControlData) {
                    return $moneyControlData;
                }
            }
            
            return null;
            
        } catch (Exception $e) {
            error_log("Web scraping error for {$symbol}: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Fetch stock news from multiple sources
     */
    public function getStockNews($symbol, $limit = 10) {
        $news = [];
        
        try {
            // Try Yahoo Finance news
            $yahooNews = $this->getYahooFinanceNews($symbol, $limit);
            if ($yahooNews) {
                $news = array_merge($news, $yahooNews);
            }
            
            // Try MoneyControl for Indian stocks
            if (strlen($symbol) > 3) { // Likely Indian stock
                $moneyControlNews = $this->getMoneyControlNews($symbol, $limit);
                if ($moneyControlNews) {
                    $news = array_merge($news, $moneyControlNews);
                }
            }
            
            // Remove duplicates and limit results
            $news = array_slice(array_unique($news, SORT_REGULAR), 0, $limit);
            
        } catch (Exception $e) {
            error_log("News scraping error for {$symbol}: " . $e->getMessage());
        }
        
        return $news;
    }
    
    /**
     * Search for stocks using web scraping
     */
    public function searchStocks($query) {
        $results = [];
        
        try {
            // Try Yahoo Finance search
            $url = "https://query1.finance.yahoo.com/v1/finance/search?q=" . urlencode($query);
            $json = $this->fetchUrl($url);
            
            if ($json) {
                $data = json_decode($json, true);
                if ($data && isset($data['quotes'])) {
                    foreach (array_slice($data['quotes'], 0, 10) as $quote) {
                        $results[] = [
                            'symbol' => $quote['symbol'],
                            'name' => $quote['longname'] ?? $quote['shortname'] ?? $quote['symbol'],
                            'source' => 'yahoo'
                        ];
                    }
                    error_log("Yahoo Finance search successful for: " . $query . ", found: " . count($results));
                    return $results;
                }
            }
            
            error_log("Yahoo Finance search failed for: " . $query . ", trying enhanced search");
            
        } catch (Exception $e) {
            error_log("Stock search error: " . $e->getMessage());
        }
        
        // Enhanced fallback search with more stocks and better matching
        $commonStocks = [
            // US Stocks
            ['symbol' => 'AAPL', 'name' => 'Apple Inc.'],
            ['symbol' => 'MSFT', 'name' => 'Microsoft Corporation'],
            ['symbol' => 'GOOGL', 'name' => 'Alphabet Inc.'],
            ['symbol' => 'AMZN', 'name' => 'Amazon.com Inc.'],
            ['symbol' => 'TSLA', 'name' => 'Tesla Inc.'],
            ['symbol' => 'META', 'name' => 'Meta Platforms Inc.'],
            ['symbol' => 'NVDA', 'name' => 'NVIDIA Corporation'],
            ['symbol' => 'NFLX', 'name' => 'Netflix Inc.'],
            ['symbol' => 'ADBE', 'name' => 'Adobe Inc.'],
            ['symbol' => 'CRM', 'name' => 'Salesforce Inc.'],
            ['symbol' => 'JPM', 'name' => 'JPMorgan Chase & Co.'],
            ['symbol' => 'JNJ', 'name' => 'Johnson & Johnson'],
            ['symbol' => 'V', 'name' => 'Visa Inc.'],
            ['symbol' => 'PG', 'name' => 'Procter & Gamble Co.'],
            ['symbol' => 'HD', 'name' => 'The Home Depot Inc.'],
            
            // Indian Stocks
            ['symbol' => 'RELIANCE', 'name' => 'Reliance Industries Limited'],
            ['symbol' => 'TCS', 'name' => 'Tata Consultancy Services Limited'],
            ['symbol' => 'INFY', 'name' => 'Infosys Limited'],
            ['symbol' => 'HDFC', 'name' => 'HDFC Bank Limited'],
            ['symbol' => 'ICICIBANK', 'name' => 'ICICI Bank Limited'],
            ['symbol' => 'HINDUNILVR', 'name' => 'Hindustan Unilever Limited'],
            ['symbol' => 'ITC', 'name' => 'ITC Limited'],
            ['symbol' => 'SBIN', 'name' => 'State Bank of India'],
            ['symbol' => 'BHARTIARTL', 'name' => 'Bharti Airtel Limited'],
            ['symbol' => 'KOTAKBANK', 'name' => 'Kotak Mahindra Bank Limited'],
            ['symbol' => 'AXISBANK', 'name' => 'Axis Bank Limited'],
            ['symbol' => 'ASIANPAINT', 'name' => 'Asian Paints Limited'],
            ['symbol' => 'MARUTI', 'name' => 'Maruti Suzuki India Limited'],
            ['symbol' => 'SUNPHARMA', 'name' => 'Sun Pharmaceutical Industries Limited'],
            ['symbol' => 'TATAMOTORS', 'name' => 'Tata Motors Limited'],
            ['symbol' => 'WIPRO', 'name' => 'Wipro Limited'],
            ['symbol' => 'ULTRACEMCO', 'name' => 'UltraTech Cement Limited'],
            ['symbol' => 'TITAN', 'name' => 'Titan Company Limited'],
            ['symbol' => 'BAJFINANCE', 'name' => 'Bajaj Finance Limited'],
            ['symbol' => 'NESTLEIND', 'name' => 'Nestle India Limited'],
            ['symbol' => 'POWERGRID', 'name' => 'Power Grid Corporation of India Limited'],
            ['symbol' => 'BAJAJFINSV', 'name' => 'Bajaj Finserv Limited'],
            ['symbol' => 'NTPC', 'name' => 'NTPC Limited'],
            ['symbol' => 'ONGC', 'name' => 'Oil and Natural Gas Corporation Limited'],
            ['symbol' => 'COALINDIA', 'name' => 'Coal India Limited'],
            ['symbol' => 'TECHM', 'name' => 'Tech Mahindra Limited'],
            ['symbol' => 'ADANIPORTS', 'name' => 'Adani Ports and Special Economic Zone Limited'],
            ['symbol' => 'HCLTECH', 'name' => 'HCL Technologies Limited'],
            ['symbol' => 'JSWSTEEL', 'name' => 'JSW Steel Limited'],
            ['symbol' => 'TATASTEEL', 'name' => 'Tata Steel Limited'],
            ['symbol' => 'VEDL', 'name' => 'Vedanta Limited'],
            ['symbol' => 'GRASIM', 'name' => 'Grasim Industries Limited'],
            ['symbol' => 'EICHERMOT', 'name' => 'Eicher Motors Limited'],
            ['symbol' => 'HEROMOTOCO', 'name' => 'Hero MotoCorp Limited'],
            ['symbol' => 'DRREDDY', 'name' => 'Dr. Reddy\'s Laboratories Limited'],
            ['symbol' => 'CIPLA', 'name' => 'Cipla Limited'],
            ['symbol' => 'BRITANNIA', 'name' => 'Britannia Industries Limited'],
            ['symbol' => 'SHREECEM', 'name' => 'Shree Cement Limited'],
            ['symbol' => 'UPL', 'name' => 'UPL Limited'],
            ['symbol' => 'ZEEL', 'name' => 'Zee Entertainment Enterprises Limited'],
            ['symbol' => 'MM', 'name' => 'Mahindra & Mahindra Limited'],
            ['symbol' => 'INFRATEL', 'name' => 'Bharti Infratel Limited'],
            ['symbol' => 'INDUSINDBK', 'name' => 'IndusInd Bank Limited'],
            ['symbol' => 'IOC', 'name' => 'Indian Oil Corporation Limited'],
            ['symbol' => 'BPCL', 'name' => 'Bharat Petroleum Corporation Limited'],
            ['symbol' => 'HINDALCO', 'name' => 'Hindalco Industries Limited']
        ];
        
        $searchTerm = strtolower($query);
        $searchWords = explode(' ', $searchTerm);
        
        // Enhanced matching algorithm
        foreach ($commonStocks as $stock) {
            $symbol = strtolower($stock['symbol']);
            $name = strtolower($stock['name']);
            
            // Exact match gets highest priority
            if ($symbol === $searchTerm || strpos($name, $searchTerm) !== false) {
                $results[] = [
                    'symbol' => $stock['symbol'],
                    'name' => $stock['name'],
                    'source' => 'fallback',
                    'match_score' => 100
                ];
            }
            // Partial match on symbol
            elseif (strpos($symbol, $searchTerm) !== false) {
                $results[] = [
                    'symbol' => $stock['symbol'],
                    'name' => $stock['name'],
                    'source' => 'fallback',
                    'match_score' => 80
                ];
            }
            // Word-based matching
            else {
                $matchScore = 0;
                foreach ($searchWords as $word) {
                    if (strlen($word) >= 2) {
                        if (strpos($symbol, $word) !== false) {
                            $matchScore += 30;
                        }
                        if (strpos($name, $word) !== false) {
                            $matchScore += 20;
                        }
                    }
                }
                
                if ($matchScore > 0) {
                    $results[] = [
                        'symbol' => $stock['symbol'],
                        'name' => $stock['name'],
                        'source' => 'fallback',
                        'match_score' => $matchScore
                    ];
                }
            }
        }
        
        // Sort by match score (highest first)
        usort($results, function($a, $b) {
            return ($b['match_score'] ?? 0) - ($a['match_score'] ?? 0);
        });
        
        // Remove duplicates and limit results
        $uniqueResults = [];
        $seenSymbols = [];
        foreach ($results as $result) {
            if (!in_array($result['symbol'], $seenSymbols)) {
                $uniqueResults[] = $result;
                $seenSymbols[] = $result['symbol'];
            }
        }
        
        error_log("Enhanced search for: " . $query . ", found: " . count($uniqueResults));
        return array_slice($uniqueResults, 0, 10);
    }
    
    /**
     * Fetch URL content with proper headers and better error handling
     */
    private function fetchUrl($url) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_USERAGENT => $this->userAgent,
            CURLOPT_HTTPHEADER => [
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language: en-US,en;q=0.5',
                'Accept-Encoding: gzip, deflate',
                'Connection: keep-alive',
                'Upgrade-Insecure-Requests: 1',
                'Cache-Control: no-cache',
                'Pragma: no-cache'
            ],
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_ENCODING => '',
            CURLOPT_REFERER => 'https://www.google.com/',
            CURLOPT_COOKIEJAR => '/tmp/cookies.txt',
            CURLOPT_COOKIEFILE => '/tmp/cookies.txt'
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        
        // Log detailed error information
        if ($error) {
            error_log("CURL Error for $url: $error");
            return false;
        }
        
        if ($httpCode !== 200) {
            error_log("HTTP Error for $url: $httpCode");
            return false;
        }
        
        if (!$response || strlen($response) < 100) {
            error_log("Empty or too short response for $url: " . strlen($response) . " characters");
            return false;
        }
        
        return $response;
    }
    
    /**
     * Parse Yahoo Finance chart data
     */
    private function parseYahooChartData($data, $symbol) {
        $result = $data['chart']['result'][0];
        $meta = $result['meta'];
        $indicators = $result['indicators']['quote'][0];
        
        $currentPrice = $meta['regularMarketPrice'] ?? 0;
        $previousClose = $meta['previousClose'] ?? $currentPrice;
        $change = $currentPrice - $previousClose;
        $changePercent = ($change / $previousClose) * 100;
        
        // Get OHLC data from indicators
        $opens = $indicators['open'] ?? [];
        $highs = $indicators['high'] ?? [];
        $lows = $indicators['low'] ?? [];
        $closes = $indicators['close'] ?? [];
        $volumes = $indicators['volume'] ?? [];
        
        // Get the latest values
        $open = !empty($opens) ? end($opens) : $currentPrice;
        $high = !empty($highs) ? max($highs) : $currentPrice;
        $low = !empty($lows) ? min($lows) : $currentPrice;
        $volume = !empty($volumes) ? end($volumes) : 0;
        $marketCap = $meta['marketCap'] ?? 0;
        
        return [
            'symbol' => $symbol,
            'price' => number_format($currentPrice, 2),
            'change' => number_format($change, 2),
            'change_percent' => number_format($changePercent, 2),
            'open' => number_format($open, 2),
            'high' => number_format($high, 2),
            'low' => number_format($low, 2),
            'previous_close' => number_format($previousClose, 2),
            'volume' => number_format($volume),
            'market_cap' => $this->formatMarketCap($marketCap),
            'source' => 'yahoo_finance',
            'last_refreshed' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * Get data from MoneyControl for Indian stocks
     */
    private function getMoneyControlData($symbol) {
        try {
            $url = "https://www.moneycontrol.com/india/stockpricequote/" . strtolower($symbol);
            $html = $this->fetchUrl($url);
            
            if ($html) {
                // Extract price using regex
                if (preg_match('/<span[^>]*class="[^"]*last_price[^"]*"[^>]*>([^<]+)<\/span>/i', $html, $matches)) {
                    $price = trim($matches[1]);
                    $price = preg_replace('/[^\d.]/', '', $price);
                    
                    if (is_numeric($price)) {
                        return [
                            'symbol' => $symbol,
                            'price' => number_format($price, 2),
                            'change' => 'N/A',
                            'change_percent' => 'N/A',
                            'volume' => 'N/A',
                            'market_cap' => 'N/A',
                            'source' => 'moneycontrol',
                            'last_refreshed' => date('Y-m-d H:i:s')
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            error_log("MoneyControl error for {$symbol}: " . $e->getMessage());
        }
        
        return null;
    }
    
    /**
     * Format market cap
     */
    private function formatMarketCap($marketCap) {
        if ($marketCap >= 1000000000) {
            return '$' . number_format($marketCap / 1000000000, 2) . 'B';
        } elseif ($marketCap >= 1000000) {
            return '$' . number_format($marketCap / 1000000, 2) . 'M';
        } else {
            return number_format($marketCap);
        }
    }
    
    /**
     * Extract price from Yahoo Finance data
     */
    private function extractPrice($data) {
        if (isset($data['price']['regularMarketPrice']['raw'])) {
            return number_format($data['price']['regularMarketPrice']['raw'], 2);
        }
        return 'N/A';
    }
    
    /**
     * Extract change from Yahoo Finance data
     */
    private function extractChange($data) {
        if (isset($data['price']['regularMarketChange']['raw'])) {
            return number_format($data['price']['regularMarketChange']['raw'], 2);
        }
        return 'N/A';
    }
    
    /**
     * Extract change percent from Yahoo Finance data
     */
    private function extractChangePercent($data) {
        if (isset($data['price']['regularMarketChangePercent']['raw'])) {
            return number_format($data['price']['regularMarketChangePercent']['raw'], 2);
        }
        return 'N/A';
    }
    
    /**
     * Extract volume from Yahoo Finance data
     */
    private function extractVolume($data) {
        if (isset($data['price']['regularMarketVolume']['raw'])) {
            return number_format($data['price']['regularMarketVolume']['raw']);
        }
        return 'N/A';
    }
    
    /**
     * Extract market cap from Yahoo Finance data
     */
    private function extractMarketCap($data) {
        if (isset($data['summaryDetail']['marketCap']['raw'])) {
            $marketCap = $data['summaryDetail']['marketCap']['raw'];
            if ($marketCap >= 1000000000) {
                return '$' . number_format($marketCap / 1000000000, 2) . 'B';
            } else {
                return '$' . number_format($marketCap / 1000000, 2) . 'M';
            }
        }
        return 'N/A';
    }
    
    /**
     * Get news from Yahoo Finance
     */
    private function getYahooFinanceNews($symbol, $limit) {
        try {
            $url = "https://feeds.finance.yahoo.com/rss/2.0/headline?s={$symbol}&region=US&lang=en-US";
            $xml = $this->fetchUrl($url);
            
            if ($xml) {
                $rss = simplexml_load_string($xml);
                if ($rss && isset($rss->channel->item)) {
                    $news = [];
                    foreach (array_slice($rss->channel->item, 0, $limit) as $item) {
                        $news[] = [
                            'title' => (string)$item->title,
                            'summary' => (string)$item->description,
                            'url' => (string)$item->link,
                            'published_date' => date('Y-m-d', strtotime((string)$item->pubDate)),
                            'source' => 'Yahoo Finance'
                        ];
                    }
                    return $news;
                }
            }
        } catch (Exception $e) {
            error_log("Yahoo Finance news error: " . $e->getMessage());
        }
        
        return [];
    }
    
    /**
     * Get news from MoneyControl (for Indian stocks)
     */
    private function getMoneyControlNews($symbol, $limit) {
        try {
            $url = "https://www.moneycontrol.com/india/stockpricequote/" . strtolower($symbol);
            $html = $this->fetchUrl($url);
            
            if ($html) {
                // Simple regex-based extraction for MoneyControl
                preg_match_all('/<h3[^>]*>.*?<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>.*?<\/h3>/s', $html, $matches, PREG_SET_ORDER);
                
                $news = [];
                foreach (array_slice($matches, 0, $limit) as $match) {
                    $news[] = [
                        'title' => strip_tags($match[2]),
                        'summary' => 'Latest news about ' . $symbol,
                        'url' => 'https://www.moneycontrol.com' . $match[1],
                        'published_date' => date('Y-m-d'),
                        'source' => 'MoneyControl'
                    ];
                }
                return $news;
            }
        } catch (Exception $e) {
            error_log("MoneyControl news error: " . $e->getMessage());
        }
        
        return [];
    }
    
    /**
     * Fetch stock data by scraping Google search results
     */
    public function getGoogleSearchStockData($symbol) {
        try {
            $query = urlencode($symbol . " stock price");
            $url = "https://www.google.com/search?q=" . $query;
            $html = $this->fetchUrl($url);
            if ($html) {
                // Try original regex
                if (preg_match('/<div[^>]*class="BNeawe iBp4i AP7Wnd"[^>]*>([\d,.]+)<\/div>/', $html, $matches)) {
                    $price = str_replace(',', '', $matches[1]);
                    // Extract change and change percent
                    if (preg_match('/<div[^>]*class="BNeawe UPmit AP7Wnd"[^>]*>([+-]?[\\d.,]+) \\(([+-]?[\\d.,]+%)\\)<\/div>/', $html, $changeMatches)) {
                        $change = $changeMatches[1];
                        $changePercent = $changeMatches[2];
                    } else {
                        $change = 'N/A';
                        $changePercent = 'N/A';
                    }
                    return [
                        'symbol' => $symbol,
                        'price' => number_format(floatval($price), 2),
                        'change' => $change,
                        'change_percent' => $changePercent,
                        'volume' => 'N/A',
                        'market_cap' => 'N/A',
                        'source' => 'google_search',
                        'last_refreshed' => date('Y-m-d H:i:s')
                    ];
                }
                // Try more flexible regex (any div with a number)
                if (preg_match('/<div[^>]*>([\d,.]+)<\/div>/', $html, $matches)) {
                    $price = str_replace(',', '', $matches[1]);
                    if (is_numeric($price)) {
                        return [
                            'symbol' => $symbol,
                            'price' => number_format(floatval($price), 2),
                            'change' => 'N/A',
                            'change_percent' => 'N/A',
                            'volume' => 'N/A',
                            'market_cap' => 'N/A',
                            'source' => 'google_search_fallback',
                            'last_refreshed' => date('Y-m-d H:i:s')
                        ];
                    }
                }
                // Log HTML for debugging if regex fails
                $logFile = __DIR__ . "/../api/google_search_failed_{$symbol}.html";
                file_put_contents($logFile, $html);
                error_log("Google search scraping failed for {$symbol}. HTML saved to $logFile");
            }
        } catch (Exception $e) {
            error_log("Google search scraping error for {$symbol}: " . $e->getMessage());
        }
        
        // Try Yahoo Finance first (better OHLC data)
        $yahooData = $this->getStockData($symbol);
        if ($yahooData) {
            $yahooData['source'] = 'yahoo_finance';
            $yahooData['note'] = 'Data from Yahoo Finance';
            return $yahooData;
        }
        
        // Try MoneyControl for Indian stocks
        $moneyControlData = $this->getMoneyControlData($symbol);
        if ($moneyControlData) {
            $moneyControlData['source'] = 'moneycontrol';
            $moneyControlData['note'] = 'Data from MoneyControl';
            return $moneyControlData;
        }
        
        // If all fail, return descriptive error
        return [
            'symbol' => $symbol,
            'error' => 'Failed to fetch stock data from Google, Yahoo, and MoneyControl.',
            'note' => 'Check if the symbol is correct or try again later.'
        ];
    }
    
    /**
     * Get stock data from Alpha Vantage (free tier)
     */
    private function getAlphaVantageData($symbol) {
        try {
            // Use a demo API key for testing (limited to 5 requests per minute)
            $apiKey = 'demo'; // You can replace with your own free API key
            $url = "https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={$symbol}&apikey={$apiKey}";
            
            $response = $this->fetchUrl($url);
            if ($response) {
                $data = json_decode($response, true);
                if ($data && isset($data['Global Quote'])) {
                    $quote = $data['Global Quote'];
                    return [
                        'symbol' => $symbol,
                        'price' => $quote['05. price'] ?? 'N/A',
                        'change' => $quote['09. change'] ?? 'N/A',
                        'change_percent' => $quote['10. change percent'] ?? 'N/A',
                        'volume' => $quote['06. volume'] ?? 'N/A',
                        'market_cap' => 'N/A',
                        'source' => 'alpha_vantage',
                        'last_refreshed' => date('Y-m-d H:i:s')
                    ];
                }
            }
        } catch (Exception $e) {
            error_log("Alpha Vantage error for {$symbol}: " . $e->getMessage());
        }
        
        return null;
    }
    
    /**
     * Get stock data from Yahoo Finance with better error handling
     */
    public function getYahooFinanceData($symbol) {
        try {
            // Try multiple Yahoo Finance endpoints
            $endpoints = [
                "https://query1.finance.yahoo.com/v8/finance/chart/{$symbol}.NS", // NSE
                "https://query1.finance.yahoo.com/v8/finance/chart/{$symbol}.BO", // BSE
                "https://query1.finance.yahoo.com/v8/finance/chart/{$symbol}",    // US
            ];
            
            foreach ($endpoints as $url) {
                $json = $this->fetchUrl($url);
                if ($json) {
                    $data = json_decode($json, true);
                    if ($data && isset($data['chart']['result'][0])) {
                        return $this->parseYahooChartData($data, $symbol);
                    }
                }
            }
        } catch (Exception $e) {
            error_log("Yahoo Finance error for {$symbol}: " . $e->getMessage());
        }
        
        return null;
    }
    
    /**
     * Enhanced stock data fetching with multiple fallbacks
     */
    public function getEnhancedStockData($symbol) {
        // Try Yahoo Finance first (most reliable)
        $data = $this->getYahooFinanceData($symbol);
        if ($data) {
            $data['source'] = 'yahoo_finance';
            $data['note'] = 'Complete OHLCV data from Yahoo Finance';
            return $data;
        }
        
        // Try Google Search
        $data = $this->getGoogleSearchStockData($symbol);
        if ($data && !isset($data['error'])) {
            return $data;
        }
        
        // Try Alpha Vantage
        $data = $this->getAlphaVantageData($symbol);
        if ($data) {
            return $data;
        }
        
        // Try MoneyControl for Indian stocks
        if (strlen($symbol) > 3) {
            $data = $this->getMoneyControlData($symbol);
            if ($data) {
                $data['source'] = 'moneycontrol';
                $data['note'] = 'Data from MoneyControl';
                return $data;
            }
        }
        
        // Return error if all methods fail
        return [
            'symbol' => $symbol,
            'error' => 'All scraping methods failed',
            'note' => 'Try again later or check symbol validity'
        ];
    }
}


// Create global scraper instance
$webScraper = new WebScraper();
?> 