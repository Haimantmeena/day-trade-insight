<?php
session_start();
$page_title = 'Login';
require_once __DIR__ . '/../includes/db_connect.php';

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error = '';
$message = '';

if (isset($_GET['message'])) {
    if ($_GET['message'] === 'signup_success') $message = "Account created successfully! Please login.";
    if ($_GET['message'] === 'logged_out') $message = "You have been logged out successfully.";
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error = "All fields are required.";
    } else {
        $stmt = $conn->prepare("SELECT id, username, email, password, role FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if ($user['role'] === 'admin') {
                $error = "Administrators must log in via the admin panel.";
            } elseif (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['email'] = $user['email'];
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Invalid credentials. Please try again.";
            }
        } else {
            $error = "Invalid credentials. Please try again.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <style>
        body {
            background: url('assets/images/login-bg.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .auth-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(5px);
        }
        .card {
            border-radius: 1rem;
            animation: fadeInUp 1s ease;
        }
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
<div class="auth-wrapper">
    <div class="col-12 col-md-8 col-lg-5 col-xl-4">
        <div class="card shadow border-0">
            <div class="card-body p-4 p-md-5">
                <h2 class="card-title text-center mb-2">📈 DayTrade Insight</h2>
                <p class="text-center text-muted mb-4">Welcome back! Please login.</p>

                <?php if ($error): ?>
                    <div class="alert alert-danger py-2"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>
                <?php if ($message): ?>
                    <div class="alert alert-success py-2"><?= htmlspecialchars($message) ?></div>
                <?php endif; ?>

                <form method="post" action="login.php" autocomplete="off">
                    <div class="form-floating mb-3">
                        <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                        <label for="email">Email address</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                        <label for="password">Password</label>
                    </div>
                    <div class="d-grid">
                        <button type="submit" name="login" class="btn btn-primary btn-lg">Login</button>
                    </div>
                </form>

                <div class="text-center mt-3">
                    <small>Don't have an account? <a href="signup.php">Sign Up</a></small>
                </div>

                <!-- Admin Login Button -->
                <div class="text-center mt-3">
                    <a href="admin/login.php" class="btn btn-outline-secondary btn-sm">👑 Admin Login</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
