<?php
// public/create_admin.php
// This script will create or reset the admin password.
require_once '../includes/db_connect.php';

// --- HTML Header for clean output ---
echo '<!DOCTYPE html><html lang="en"><head><title>Admin Setup</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head><body class="bg-light">';
echo '<div class="container mt-5"><div class="card shadow-sm"><div class="card-body">';
echo '<h1>Admin Account Setup & Fix</h1>';
echo '<p>This script checks for an admin account and ensures the password is set correctly.</p><hr>';

// --- Admin Details ---
$admin_email = 'admin@daytrade.com';
$admin_username = 'admin';
$admin_password_to_set = 'adminpassword';

// Hash the password securely using your server's PHP version
$hashed_password = password_hash($admin_password_to_set, PASSWORD_DEFAULT);

// Check if the admin user already exists based on the email
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // --- User Exists: UPDATE their password ---
    echo '<h4>Status: Admin User Found.</h4>';
    $user = $result->fetch_assoc();
    $user_id = $user['id'];
    
    $update_stmt = $conn->prepare("UPDATE users SET password = ?, role = 'admin' WHERE id = ?");
    $update_stmt->bind_param("si", $hashed_password, $user_id);
    
    if ($update_stmt->execute()) {
        echo '<div class="alert alert-success">Admin account password has been successfully **RESET**. You can now log in.</div>';
    } else {
        echo '<div class="alert alert-danger">Error updating admin password: ' . htmlspecialchars($update_stmt->error) . '</div>';
    }
    $update_stmt->close();

} else {
    // --- User Does Not Exist: INSERT a new one ---
    echo '<h4>Status: No Admin User Found. Creating a new one.</h4>';
    $insert_stmt = $conn->prepare("INSERT INTO users (username, email, password, role, subscription_status) VALUES (?, ?, ?, 'admin', 'premium')");
    $insert_stmt->bind_param("sss", $admin_username, $admin_email, $hashed_password);
    
    if ($insert_stmt->execute()) {
        echo '<div class="alert alert-success">Admin account created successfully!</div>';
    } else {
        echo '<div class="alert alert-danger">Error creating admin account: ' . htmlspecialchars($insert_stmt->error) . '</div>';
    }
    $insert_stmt->close();
}

$stmt->close();
$conn->close();

echo '<hr>';
echo '<h5>Login Details:</h5>';
echo '<ul>';
echo '<li>Email: <strong>' . $admin_email . '</strong></li>';
echo '<li>Password: <strong>' . $admin_password_to_set . '</strong></li>';
echo '</ul>';
echo '<a href="admin/index.php" class="btn btn-primary mt-3">Go to Admin Login Page</a>';
echo '<p class="mt-4 text-danger"><b>Important:</b> For security, please delete this file (create_admin.php) from your server after you have successfully logged in.</p>';
echo '</div></div></div></body></html>';
?>
