<?php
// सभी एरर को दिखाने के लिए इसे सबसे ऊपर रखें
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>API कनेक्शन टेस्ट</h1>";

// 1. जांचें कि cURL एक्सटेंशन सक्षम है या नहीं
if (function_exists('curl_init')) {
    echo "<p style='color:green;'>✅ cURL एक्सटेंशन सक्षम (Enabled) है।</p>";
} else {
    echo "<p style='color:red;'>❌ <strong>समस्या:</strong> cURL एक्सटेंशन सक्षम नहीं है। आपको अपनी php.ini फाइल में इसे सक्षम करना होगा।</p>";
    exit;
}

// 2. Web scraping test
$keywords = 'TCS';
echo "<p>Testing web scraping for: " . htmlspecialchars($keywords) . "</p>";

require_once '../includes/web_scraper.php';
global $webScraper;

$results = $webScraper->searchStocks($keywords);
echo "<p>Search results: " . count($results) . " found</p>";
foreach ($results as $result) {
    echo "<p>- " . $result['symbol'] . " (" . $result['name'] . ")</p>";
}

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20); // कनेक्शन के लिए टाइमआउट बढ़ाया गया

// SSL वेरिफिकेशन को बायपास करें (केवल लोकल सर्वर के लिए)
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

$response = curl_exec($ch);

// 3. परिणाम की जांच करें
if (curl_errno($ch)) {
    // अगर cURL में कोई एरर है
    echo "<p style='color:red;'>❌ <strong>cURL Error:</strong> " . curl_error($ch) . "</p>";
    echo "<p><strong>सुझाव:</strong> यह एरर अक्सर तब आता है जब आपका फ़ायरवॉल या एंटीवायरस PHP को इंटरनेट से कनेक्ट करने से रोक रहा हो।</p>";
} else {
    // अगर कनेक्शन सफल रहा
    echo "<p style='color:green;'>✅ कनेक्शन सफल रहा!</p>";
    echo "<h3>सर्वर से मिला रिस्पांस:</h3>";
    echo "<pre>";
    print_r(json_decode($response, true));
    echo "</pre>";
}

curl_close($ch);
?>