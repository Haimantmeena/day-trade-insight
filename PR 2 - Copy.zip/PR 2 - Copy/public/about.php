<?php
$page_title = 'About Us';
require_once '../includes/db_connect.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
include 'partials/header.php';
include 'partials/navbar.php';
?>
<style>
    /* Custom animation for About page sections */
    .about-section { opacity: 0; transform: translateY(40px); transition: all 0.8s cubic-bezier(.4,0,.2,1); }
    .about-section.visible { opacity: 1; transform: none; }
    .about-icon { font-size: 2.2rem; margin-right: 0.5rem; vertical-align: middle; }
    .about-divider { border-top: 2px dashed #0d6efd; margin: 2.5rem 0 2rem 0; }
</style>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const sections = document.querySelectorAll('.about-section');
        const reveal = () => {
            sections.forEach(sec => {
                const rect = sec.getBoundingClientRect();
                if (rect.top < window.innerHeight - 80) sec.classList.add('visible');
            });
        };
        window.addEventListener('scroll', reveal);
        reveal();
    });
</script>
<main class="container main-content">
    <div class="row justify-content-center">
        <div class="col-lg-9">
            <div class="card text-center p-4 p-md-5 shadow-lg bg-light border-0">
                <div class="card-body">
                    <!-- Hero Section -->
                    <h1 class="card-title mb-2 display-5 fw-bold text-primary about-section">About DayTrade Insight</h1>
                    <p class="lead text-muted mb-4 about-section">Empowering you to make smarter, faster decisions in the Indian stock market.</p>
                    <div class="text-start">
                        <!-- Main Heading -->
                        <h2 class="mb-3 fw-bold text-dark about-section"><span class="about-icon">🤝</span> Your Trusted Partner</h2>
                        <h5 class="mb-4 text-secondary about-section">We combine cutting-edge technology with deep market insight to help you trade with confidence.</h5>
                        <div class="about-divider"></div>
                        <!-- Section 1: Our Mission -->
                        <h4 class="fw-semibold text-primary about-section"><span class="about-icon">🎯</span> Our Mission</h4>
                        <p class="about-section">Our mission is to level the playing field for retail investors. We bring you the advanced tools and insights once reserved for big institutions, so you can trade with clarity and confidence. At DayTrade Insight, we believe everyone deserves access to smart, data-driven decision-making—no matter their experience level.</p>
                        <div class="about-divider"></div>
                        <!-- Section 2: What We Do -->
                        <h4 class="fw-semibold text-success about-section"><span class="about-icon">💡</span> What We Do</h4>
                        <p class="about-section">DayTrade Insight is your all-in-one platform for live Indian stock analysis. We blend real-time data from the Upstox API with rich historical insights from our MySQL database. Our custom AI model delivers instant stock search, live price quotes, and—most importantly—AI-powered buy, sell, or hold signals. We turn complex data into clear, actionable insights, so you can spot opportunities and act fast.</p>
                        <div class="about-divider"></div>
                        <!-- Section 3: Our Team -->
                        <h4 class="fw-semibold text-warning about-section"><span class="about-icon">👨‍💻</span> Our Team</h4>
                        <p class="about-section">Founded in Surat, Gujarat, DayTrade Insight is powered by a passionate team of developers, machine learning experts, and market enthusiasts. We’re united by a single goal: to make stock market analysis smarter, simpler, and more accessible for everyone. Our diverse backgrounds help us build a platform that’s both powerful and easy to use.</p>
                        <div class="about-divider"></div>
                        <!-- Section 4: Our Technology and Approach -->
                        <h4 class="fw-semibold text-info about-section"><span class="about-icon">⚙️</span> Our Technology & Approach</h4>
                        <p class="about-section">Our platform is built for speed, security, and scalability. We use a robust PHP backend, a Python-based AI microservice (Flask), and a reliable MySQL database. Live market data comes straight from the trusted Upstox API. Our AI model is always learning, so your insights get sharper every day. We’re committed to keeping your data safe and your experience seamless.</p>
                        <div class="about-divider"></div>
                        <!-- Section 5: Important Disclaimer -->
                        <h4 class="fw-semibold text-danger about-section"><span class="about-icon">⚠️</span> Important Disclaimer</h4>
                        <p class="about-section">All insights and predictions from DayTrade Insight are for informational and educational purposes only—they are <strong>not</strong> financial advice. The stock market involves risk. Please consult a financial advisor before making investment decisions. DayTrade Insight is not responsible for any financial losses.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php include 'partials/footer.php'; ?>
