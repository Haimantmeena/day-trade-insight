<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}
$page_title = 'Welcome to DayTrade Insight';
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Animate.css for fade-in effects -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <!-- Custom Styles -->
    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        /* Animated gradient background */
        @keyframes gradientBackground {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            overflow-x: hidden;
        }

        .hero-section {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            text-align: center;
            color: #ffffff;
            background: linear-gradient(-45deg, #0f2027, #203a43, #2c5364, #1f4037);
            background-size: 400% 400%;
            animation: gradientBackground 15s ease infinite;
            padding: 2rem;
        }

        .hero-title {
            font-size: 3rem;
            font-weight: bold;
        }

        .hero-subtitle {
            font-size: 1.3rem;
            color: #ddd;
        }

        .btn-custom {
            padding: 0.8rem 2rem;
            font-size: 1.1rem;
        }

        .footer {
            background-color: #000;
            color: #fff;
        }

        .animate__fadeInUp {
            animation: fadeInUp 1s ease-in-out both;
        }
    </style>
</head>
<body class="animate__animated animate__fadeIn">

<!-- Hero Section -->
<!-- Hero Section with Animated Background -->
<section class="hero-section position-relative overflow-hidden">
  <canvas id="hero-canvas" class="position-absolute top-0 start-0 w-100 h-100"></canvas>
  <div class="container hero-content position-relative text-center">
    <h1 class="hero-title">📈 Welcome to DayTrade Insight</h1>
    <p class="hero-subtitle mt-3">Analyze Indian stock market trends with AI & Data Science.</p>
    <div class="mt-4">
      <a href="login.php" class="btn btn-light btn-custom me-3">🔑 User Login</a>
      <a href="signup.php" class="btn btn-outline-light btn-custom">📝 Sign Up</a>
    </div>
    <div class="mt-4">
      <a href="admin/index.php" class="text-white">Login as Administrator</a>
    </div>
  </div>
</section>


<!-- Footer -->
<footer class="footer py-4 text-center">
    <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> DayTrade Insight. All rights reserved.</p>
    </div>
</footer>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/tsparticles@2/tsparticles.bundle.min.js"></script>
<script>
  tsParticles.load("hero-canvas", {
    fullScreen: false,
    detectRetina: true,
    particles: {
      number: { value: 80 },
      color: { value: "#ffffff" },
      shape: { type: "image", image: { src: "https://example.com/animated-stock1.png"
 , width: 32, height: 32 } },
      opacity: { value: 0.6 },
      size: { value: { min: 8, max: 24 } },
      move: { enable: true, speed: 1.5, outModes: "out" }
    },
    interactivity: {
      events: {
        onHover: { enable: true, mode: "repulse" },
        onClick: { enable: true, mode: "push" }
      },
      modes: {
        repulse: { distance: 100 },
        push: { quantity: 4 }
      }
    }
  });
</script>

</body>
</html>
