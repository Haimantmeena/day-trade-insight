<?php
session_start();
$page_title = 'Dashboard';
require_once '../includes/db_connect.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'partials/header.php';
include 'partials/navbar.php';
?>

<main class="main-content-area py-5">
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-lg-10"> <!-- Increased from col-lg-8 to col-lg-10 -->

                <!-- Welcome Message -->
                <div class="text-center mb-4" data-aos="fade-up">
                    <h1 class="fw-bold">Welcome, <?= htmlspecialchars($_SESSION['username']); ?> 👋</h1>
                    <p class="text-muted fs-5">Analyze market data with AI-powered insights.</p>
                </div>

                <!-- Search Card -->
                <div class="card shadow-sm mb-4 dashboard-search-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="card-body" style="position: relative;">
                        <h4 class="mb-3 fw-semibold text-primary">🔍 Search for a Stock</h4>
                        <div class="input-group input-group-lg dashboard-search-group">
                            <input type="text" id="company-symbol" class="form-control" placeholder="Search stocks from your list (e.g., RELIANCE, INFY)" autocomplete="off">
                            <button id="fetch-btn" class="btn btn-primary" type="button">
                                <span id="btn-text">Search</span>
                            </button>
                        </div>
                        <!-- Search results dropdown will appear here -->
                        <!-- Removed search results dropdown to disable suggestions -->
                        <div id="search-results" class="list-group position-absolute w-100 mt-1" style="z-index: 1000; display: none; visibility: hidden;"></div>
                    </div>
                </div>

                <!-- Dynamic Content Area -->
                <div id="dynamic-content-area">
                    <!-- Error Message Area -->
                    <div id="error-msg" class="alert alert-danger d-none mt-3"></div>

                    <!-- Loader -->
                    <div id="loader" class="text-center py-5 d-none">
                        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;"></div>
                        <p class="mt-3 fw-semibold">Fetching live stock data...</p>
                    </div>

                    <!-- Main Results Container -->
                    <div id="main-content-results" class="d-none dashboard-card-grid">
                        <!-- Stock Info Card (filled by JS) -->
                        <div id="stock-info-card" class="card shadow-sm mb-4" data-aos="fade-up"></div>

                        <!-- News Section (NEW) -->
                        <div class="card shadow-sm mb-4" id="main-news-card" data-aos="fade-up" style="display:none;">
                            <div class="card-body">
                                <h5 class="mb-3 text-primary"><span style="font-size:1.5rem;vertical-align:middle;">📰</span> Latest News</h5>
                                <div id="main-news-list-container">
                                    <!-- JS will inject news here -->
                                </div>
                            </div>
                        </div>

                        <!-- AI Analysis Button -->
                        <div class="d-grid mb-4" data-aos="fade-up" data-aos-delay="100">
                            <button id="ai-analyze-btn" class="btn btn-success btn-lg">
                                🤖 Run AI Analysis & View News
                            </button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</main>

<!-- AI Analysis and News Modal -->
<div class="modal fade" id="analysis-modal" tabindex="-1" aria-labelledby="analysisModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content shadow-lg">
            <div class="modal-header">
                <h5 class="modal-title" id="analysis-modal-title">AI Analysis & News</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <!-- Left side: AI Analysis -->
                    <div class="col-lg-6" id="prediction-container">
                        <!-- JS will inject AI analysis here -->
                    </div>
                    <!-- Right side: News -->
                    <div class="col-lg-6 border-start">
                         <h5 class="mb-3">Latest News</h5>
                         <div id="news-list-container">
                            <!-- JS will inject news here -->
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Stock Detail Modal for Card Click -->
<div class="modal fade" id="stock-detail-modal" tabindex="-1" aria-labelledby="stockDetailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content shadow-lg">
            <div class="modal-header">
                <h5 class="modal-title" id="stockDetailModalLabel">Stock Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="stock-detail-modal-body"><!-- JS will inject card here --></div>
            </div>
        </div>
    </div>
</div>

<?php include 'partials/footer.php'; ?>
