<?php
$page_title = 'Top Stocks';
require_once '../includes/db_connect.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

// डेटा को प्रतीक के अनुसार क्रमबद्ध करना बेहतर है ताकि सूची स्थिर रहे
$stock_result = $conn->query("SELECT * FROM stocks ORDER BY symbol ASC LIMIT 50");

include 'partials/header.php';
include 'partials/navbar.php';
?>

<main class="main-content-area">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <h1>Top Indian Companies</h1>
            <p class="lead text-muted">Use the search below to filter the list in real-time.</p>
        </div>

        <div id="stock-card-container">
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <?php while($stock = $stock_result->fetch_assoc()): 
                    $is_positive = ($stock['price_change'] ?? 0) >= 0;
                    $gradient_num = rand(1, 6);
                ?>
                    <div class="col" data-aos="fade-up" data-aos-delay="100">
                        <div class="card h-100 shadow-sm stock-card custom-card modern animated-gradient gradient-<?php echo $gradient_num; ?>"
                             data-symbol="<?php echo htmlspecialchars($stock['symbol']); ?>"
                             data-price="<?php echo $stock['close_price'] ?? 0; ?>"
                             data-change="<?php echo $stock['price_change'] ?? 0; ?>"
                             data-marketcap="<?php echo $stock['market_cap'] ?? 0; ?>"
                             data-company_name="<?php echo htmlspecialchars($stock['company_name']); ?>"
                             data-founded_year="<?php echo $stock['founded_year'] ?? ''; ?>"
                             data-date="<?php echo isset($stock['date']) ? date('d M Y', strtotime($stock['date'])) : ''; ?>"
                             style="cursor:pointer;">
                            
                            <div class="card-body p-4">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h5 class="card-title fw-bold text-primary"><?php echo htmlspecialchars($stock['symbol']); ?></h5>
                                    <span class="fs-5 fw-semibold <?php echo $is_positive ? 'text-success' : 'text-danger'; ?>">
                                        <?php echo $is_positive ? '▲' : '▼'; ?> 
                                        <?php echo number_format(abs($stock['price_change'] ?? 0), 2); ?>%
                                    </span>
                                </div>
                                <p class="card-subtitle mb-3 text-muted"><?php echo htmlspecialchars($stock['company_name']); ?></p>
                                <h4 class="fw-bolder text-dark">₹<?php echo number_format($stock['close_price'] ?? 0, 2); ?></h4>
                            </div>
                            <div class="card-footer bg-white border-0 d-flex justify-content-between align-items-center pt-3">
                                <div>
                                    <small class="text-muted d-block">Market Cap: ₹<?php echo number_format($stock['market_cap'] ?? 0); ?> Cr</small>
                                    <small class="text-muted d-block">Founded: <?php echo $stock['founded_year'] ?? 'N/A'; ?></small>
                                    <small class="text-muted">Last Updated: <?php echo isset($stock['date']) ? date('d M Y', strtotime($stock['date'])) : 'N/A'; ?></small>
                                </div>
                                <button class="btn btn-outline-primary btn-sm ai-analyze-stocklist-btn rounded-pill shadow-sm">AI Analyze</button>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</main>

<!-- Modal for showing analysis and News -->
<div class="modal fade" id="analysis-modal" tabindex="-1" aria-labelledby="analysisModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="analysis-modal-title">AI Analysis & News</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-6" id="prediction-container">
                        <!-- JS will inject AI analysis here -->
                    </div>
                    <div class="col-lg-6 border-start">
                         <h5 class="mb-3">Latest News</h5>
                         <div id="news-list-container">
                            <!-- JS will inject news here -->
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'partials/footer.php'; ?>
