<footer class="footer mt-auto py-4 bg-dark text-white" data-aos="fade-up">
    <div class="container text-center">
        <div class="row g-4">
            <div class="col-md-4">
                <h5 class="text-warning">📈 DayTrade Insight</h5>
                <p class="small">Smart Stock Prediction System for Enhanced Trading Decisions using AI.</p>
            </div>
            <div class="col-md-4">
                <h5 class="text-warning">🔗 Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white text-decoration-none">🏠 Home</a></li>
                    <li><a href="stocklist.php" class="text-white text-decoration-none">📊 Stocks</a></li>
                    <li><a href="contact.php" class="text-white text-decoration-none">📞 Contact</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5 class="text-warning">🌐 Follow Us</h5>
                <a href="#" class="text-white fs-5 me-3"><i class="fab fa-twitter"></i></a>
                <a href="#" class="text-white fs-5 me-3"><i class="fab fa-linkedin"></i></a>
                <a href="#" class="text-white fs-5"><i class="fab fa-github"></i></a>
            </div>
        </div>
        <hr class="border-light mt-4">
        <p class="text-muted small mb-0">&copy; <?php echo date("Y"); ?> DayTrade Insight. Internship Project.</p>
    </div>
</footer>

<!-- Back to Top Button -->
<button id="back-to-top" aria-label="Back to Top" title="Back to Top">↑</button>
<script>
  // Show/hide back to top button
  window.addEventListener('scroll', function() {
    const btn = document.getElementById('back-to-top');
    if (window.scrollY > 300) {
      btn.classList.add('show');
    } else {
      btn.classList.remove('show');
    }
  });
  // Scroll to top on click
  document.getElementById('back-to-top').onclick = function() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
</script>

<!-- Floating Bird Chat Widget -->
<div id="ai-faq-widget">
  <button id="ai-faq-bird-btn" aria-label="Ask AI about Stocks">
    <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
      <ellipse cx="22" cy="22" rx="20" ry="20" fill="url(#bird-bg)" opacity="0.7"/>
      <path d="M14 28 Q18 18 30 18 Q34 18 32 22 Q30 26 22 28 Q18 29 14 28 Z" fill="#fff"/>
      <circle cx="28" cy="22" r="2" fill="#222"/>
      <ellipse cx="32" cy="20" rx="1.2" ry="0.6" fill="#222"/>
      <path d="M30 18 Q32 16 34 18" stroke="#222" stroke-width="1.2" fill="none"/>
      <defs>
        <radialGradient id="bird-bg" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0%" stop-color="#43c6ac"/>
          <stop offset="100%" stop-color="#185a9d"/>
        </radialGradient>
      </defs>
    </svg>
  </button>
  <div id="ai-faq-panel" class="glassmorphism">
    <div class="faq-header">
      <span>🦜 Ask AI about Stocks</span>
      <button id="ai-faq-close" aria-label="Close FAQ">&times;</button>
      <button id="ai-faq-theme-toggle" aria-label="Toggle Theme">🌓</button>
    </div>
    <div class="faq-list"></div>
    <div class="faq-chat-coming-soon" id="faq-chat-coming-soon">
      <button id="ai-faq-chat-btn" class="faq-chat-btn">💬 Chat (not yet added)</button>
      <div id="ai-faq-chat-message" class="faq-chat-message">Live chat with AI is coming soon! For now, please use the FAQ or <a href="contact.php">contact us</a>.</div>
    </div>
  </div>
</div>

<!-- JS Libraries -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/echarts@5.5.0/dist/echarts.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://kit.fontawesome.com/a2e0f1f0b8.js" crossorigin="anonymous"></script>
<script src="assets/js/main.js"></script>

<!-- AOS Animation Init -->
<script>
    AOS.init({ duration: 800, once: true, offset: 50 });

    // Back to top button show/hide
    const backToTop = document.getElementById('back-to-top');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            backToTop.classList.remove('d-none');
        } else {
            backToTop.classList.add('d-none');
        }
    });
</script>
