<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection (absolute correct path)
require_once __DIR__ . '/../../includes/db_connect.php';
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? htmlspecialchars($page_title) : 'DayTrade Insight'; ?></title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Animate on Scroll (AOS) -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/images/favicon.png">

    <!-- Meta SEO -->
    <meta name="description" content="DayTrade Insight - Analyze Indian stock market trends using AI and data science.">
    <meta name="author" content="DayTrade Insight Team">
    <meta name="theme-color" content="#0f2027">

    <!-- Smooth animations -->
    <style>
        html {
            scroll-behavior: smooth;
        }

        body.fade-in {
            opacity: 0;
            animation: fadeIn 0.6s ease-in-out forwards;
        }

        @keyframes fadeIn {
            to { opacity: 1; }
        }

        .main-content-area {
            min-height: 85vh;
        }
    </style>
</head>
<body class="fade-in">
