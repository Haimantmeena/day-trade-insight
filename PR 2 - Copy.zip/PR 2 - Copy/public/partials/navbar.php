<?php $username = $_SESSION['username'] ?? 'Guest'; ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm fixed-top" data-aos="fade-down">
    <div class="container-fluid">
        <a class="navbar-brand d-flex align-items-center fw-bold fs-4" href="dashboard.php">
            <span class="me-2" style="font-size: 2rem;">📈</span> DayTrade Insight
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main-nav" aria-controls="main-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="main-nav">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0 gap-lg-3">
                <li class="nav-item"><a class="nav-link text-white fw-semibold" href="dashboard.php">🔍 Search</a></li>
                <li class="nav-item"><a class="nav-link text-white fw-semibold" href="stocklist.php">📊 Top Stocks</a></li>
                <li class="nav-item"><a class="nav-link text-white fw-semibold" href="contact.php">📞 Contact</a></li>
                <li class="nav-item"><a class="nav-link text-white fw-semibold" href="about.php">ℹ️ About</a></li>
            </ul>

            <div class="d-flex align-items-center gap-3">
                <!-- Dark Mode Toggle Switch -->
                <div class="form-check form-switch text-white me-3">
                    <input class="form-check-input" type="checkbox" id="theme-switcher">
                    <label class="form-check-label" for="theme-switcher"> 19</label>
                </div>

                <!-- User Dropdown -->
                <div class="dropdown">
                    <button class="btn btn-light btn-sm dropdown-toggle fw-semibold" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        👤 <?php echo htmlspecialchars($username); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end animate__animated animate__fadeIn">
                        <li><a class="dropdown-item" href="settings.php">⚙️ Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php">🚪 Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>
