<?php
// Test search functionality
require_once '../includes/config.php';
require_once '../includes/web_scraper.php';

echo "<h1>Search Test</h1>";

// Test web scraper search
global $webScraper;

$testQueries = ['AAPL', 'MSFT', 'RELIANCE', 'TCS', 'GOOGL'];

foreach ($testQueries as $query) {
    echo "<h3>Testing search for: $query</h3>";
    
    $results = $webScraper->searchStocks($query);
    
    if (!empty($results)) {
        echo "<p>Found " . count($results) . " results:</p>";
        echo "<ul>";
        foreach ($results as $result) {
            echo "<li><strong>{$result['symbol']}</strong> - {$result['name']} (Source: {$result['source']})</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>No results found</p>";
    }
    
    echo "<hr>";
}

// Test API endpoint
echo "<h3>Testing API endpoint</h3>";
$apiUrl = "http://localhost/pr/PR%202/api/search_stocks.php?q=AAPL";
echo "<p>API URL: $apiUrl</p>";

$response = file_get_contents($apiUrl);
if ($response) {
    $data = json_decode($response, true);
    echo "<p>API Response:</p>";
    echo "<pre>" . print_r($data, true) . "</pre>";
} else {
    echo "<p>API request failed</p>";
}
?> 