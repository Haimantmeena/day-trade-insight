</main> <!-- Closing main content from header -->

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<!-- Bootstrap JS Bundle (includes Popper for dropdowns) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Chart.js for Dashboard Analytics -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.2/dist/chart.umd.min.js"></script>

<!-- DataTables for User Table -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<!-- Optional: You can add some fade-in animation on page load -->
<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.body.classList.add('fade-in');
    });
</script>

<!-- Optional: Basic CSS for page fade-in animation -->
<style>
    body.fade-in {
        opacity: 0;
        animation: fadeIn 0.6s ease-in forwards;
    }
    @keyframes fadeIn {
        to {
            opacity: 1;
        }
    }
</style>

</body>
</html>
