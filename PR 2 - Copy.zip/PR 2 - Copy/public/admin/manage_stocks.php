<?php
// public/admin/manage_stocks.php

$page_title = 'Manage Stocks';
// हेडर और डेटाबेस कनेक्शन शामिल करें
include 'partials/header.php';

// --- फॉर्म सबमिशन को हैंडल करें ---

// नया स्टॉक जोड़ें
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_stock'])) {
    $symbol = trim(strtoupper($_POST['symbol']));
    $company_name = trim($_POST['company_name']);

    if (!empty($symbol) && !empty($company_name)) {
        // जांचें कि स्टॉक पहले से मौजूद तो नहीं है
        $check_stmt = $conn->prepare("SELECT id FROM stocks WHERE symbol = ?");
        $check_stmt->bind_param("s", $symbol);
        $check_stmt->execute();
        $result = $check_stmt->get_result();

        if ($result->num_rows == 0) {
            // स्टॉक डालें
            $insert_stmt = $conn->prepare("INSERT INTO stocks (symbol, company_name) VALUES (?, ?)");
            $insert_stmt->bind_param("ss", $symbol, $company_name);
            $insert_stmt->execute();
            $insert_stmt->close();
            echo '<div class="alert alert-success">Stock ' . htmlspecialchars($symbol) . ' added successfully.</div>';
        } else {
            echo '<div class="alert alert-warning">Stock ' . htmlspecialchars($symbol) . ' already exists.</div>';
        }
        $check_stmt->close();
    } else {
        echo '<div class="alert alert-danger">Symbol and Company Name are required.</div>';
    }
}

// स्टॉक हटाएं
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_stock'])) {
    $stock_id = (int)$_POST['stock_id'];
    $delete_stmt = $conn->prepare("DELETE FROM stocks WHERE id = ?");
    $delete_stmt->bind_param("i", $stock_id);
    $delete_stmt->execute();
    $delete_stmt->close();
    echo '<div class="alert alert-info">Stock deleted successfully.</div>';
}

// सभी मौजूदा स्टॉक प्राप्त करें
$all_stocks = $conn->query("SELECT id, symbol, company_name FROM stocks ORDER BY symbol ASC");

?>

<div class="container py-4">
    <h1 class="h3 fw-bold mb-4">📈 Manage Top Stocks</h1>

    <div class="card shadow-sm mb-4">
        <div class="card-header">
            <h5 class="mb-0">Add New Stock</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="manage_stocks.php">
                <div class="row g-3 align-items-end">
                    <div class="col-md-5">
                        <label for="symbol" class="form-label">Stock Symbol (e.g., WIPRO)</label>
                        <input type="text" class="form-control" id="symbol" name="symbol" required>
                    </div>
                    <div class="col-md-5">
                        <label for="company_name" class="form-label">Company Name</label>
                        <input type="text" class="form-control" id="company_name" name="company_name" required>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" name="add_stock" class="btn btn-primary w-100">Add Stock</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header">
            <h5 class="mb-0">Existing Stocks List</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-dark table-striped table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Symbol</th>
                        <th>Company Name</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($all_stocks->num_rows > 0): ?>
                        <?php while ($stock = $all_stocks->fetch_assoc()): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($stock['symbol']); ?></strong></td>
                                <td><?php echo htmlspecialchars($stock['company_name']); ?></td>
                                <td class="text-end">
                                    <form method="POST" action="manage_stocks.php" onsubmit="return confirm('Are you sure you want to delete this stock?');">
                                        <input type="hidden" name="stock_id" value="<?php echo $stock['id']; ?>">
                                        <button type="submit" name="delete_stock" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" class="text-center">No stocks found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
// फुटर शामिल करें
include 'partials/footer.php';
?>