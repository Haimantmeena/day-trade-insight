<?php
$page_title = 'Admin Dashboard';
include 'partials/header.php';

// Dashboard stats
$total_users = $conn->query("SELECT COUNT(*) AS count FROM users WHERE role = 'user'")->fetch_assoc()['count'];
$premium_users = $conn->query("SELECT COUNT(*) AS count FROM users WHERE subscription_status = 'premium'")->fetch_assoc()['count'];
$pending_requests = $conn->query("SELECT COUNT(*) AS count FROM users WHERE subscription_status = 'pending'")->fetch_assoc()['count'];
$unread_messages = $conn->query("SELECT COUNT(*) AS count FROM contact_messages WHERE is_read = 0")->fetch_assoc()['count'];

// Chart data (last 7 days of user registrations)
$chart_data = [];
$chart_labels = [];
$result = $conn->query("
    SELECT DATE(created_at) AS reg_date, COUNT(*) AS total 
    FROM users 
    WHERE created_at >= CURDATE() - INTERVAL 6 DAY 
    GROUP BY DATE(created_at)
    ORDER BY reg_date ASC
");
while ($row = $result->fetch_assoc()) {
    $chart_labels[] = date("D", strtotime($row['reg_date']));
    $chart_data[] = $row['total'];
}
?>

<div class="container py-4">
    <h1 class="h3 mb-4 fw-bold">📊 Admin Dashboard</h1>

    <div class="row g-4">
        <?php
        $stats = [
            ["Total Users", $total_users, "bi-people-fill", "primary"],
            ["Premium Users", $premium_users, "bi-gem", "success"],
            ["Pending Requests", $pending_requests, "bi-clock-history", "warning"],
            ["Unread Messages", $unread_messages, "bi-envelope-fill", "info"]
        ];
        foreach ($stats as [$label, $count, $icon, $color]): ?>
            <div class="col-md-6 col-xl-3">
                <div class="card text-white bg-<?= $color ?> shadow-sm h-100 animate__animated animate__fadeInUp">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div>
                            <h4 class="fw-bold"><?= $count ?></h4>
                            <p class="mb-0"><?= $label ?></p>
                        </div>
                        <i class="bi <?= $icon ?> fs-2"></i>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<div class="text-end mb-3">
  <a href="news_fetcher.html" target="_blank" class="btn btn-outline-primary btn-sm rounded-pill shadow-sm">
    📰 Fetch Latest News
  </a>
</div>

    <div class="card mt-5 shadow animate__animated animate__fadeInUp">
        <div class="card-header bg-dark text-white">
            <i class="bi bi-bar-chart-fill me-2"></i> User Registrations (Last 7 Days)
        </div>
        <div class="card-body">
            <canvas id="userChart" height="100"></canvas>
        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
    const ctx = document.getElementById('userChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= json_encode($chart_labels) ?>,
            datasets: [{
                label: 'Users',
                data: <?= json_encode($chart_data) ?>,
                borderColor: '#0d6efd',
                backgroundColor: 'rgba(13, 110, 253, 0.2)',
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#fff',
                pointBorderColor: '#0d6efd'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
});
</script>

<?php include 'partials/footer.php'; ?>
