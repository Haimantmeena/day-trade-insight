<?php
$page_title = 'Manage Users';
include 'partials/header.php';

// Handle status update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'], $_POST['user_id'])) {
        $user_id = (int)$_POST['user_id'];

        if ($_POST['action'] === 'approve') {
            $conn->query("UPDATE users SET subscription_status = 'premium' WHERE id = $user_id");
        } elseif ($_POST['action'] === 'cancel') {
            $conn->query("UPDATE users SET subscription_status = 'cancelled' WHERE id = $user_id");
        } elseif ($_POST['action'] === 'delete') {
            $conn->query("DELETE FROM users WHERE id = $user_id");
        } elseif ($_POST['action'] === 'edit' && isset($_POST['username'], $_POST['email'])) {
            $username = $conn->real_escape_string(trim($_POST['username']));
            $email = $conn->real_escape_string(trim($_POST['email']));
            $conn->query("UPDATE users SET username = '$username', email = '$email' WHERE id = $user_id");
        }
    }
}

// Fetch users
$result = $conn->query("SELECT id, username, email, subscription_status, created_at FROM users WHERE role = 'user' ORDER BY created_at DESC");
?>

<div class="container py-4">
    <h1 class="h3 fw-bold mb-4">👥 Manage Users</h1>

    <div class="table-responsive shadow-sm animate__animated animate__fadeIn">
        <table class="table table-dark table-bordered table-hover align-middle">
            <thead class="table-light text-center">
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Joined</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($user = $result->fetch_assoc()): ?>
                    <tr class="<?= $user['subscription_status'] === 'pending' ? 'table-warning fw-bold' : '' ?>">
                        <td><?= $user['id'] ?></td>
                        <form method="POST">
                            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                            <td><input type="text" name="username" class="form-control form-control-sm" value="<?= htmlspecialchars($user['username']) ?>" required></td>
                            <td><input type="email" name="email" class="form-control form-control-sm" value="<?= htmlspecialchars($user['email']) ?>" required></td>
                            <td class="text-center">
                                <?php
                                $status = ucfirst($user['subscription_status']);
                                $badge = match ($user['subscription_status']) {
                                    'premium' => 'success',
                                    'pending' => 'warning',
                                    'cancelled' => 'danger',
                                    default => 'secondary'
                                };
                                ?>
                                <span class="badge bg-<?= $badge ?>"><?= $status ?></span>
                            </td>
                            <td><?= date('d M Y', strtotime($user['created_at'])) ?></td>
                            <td class="text-nowrap text-center">
                                <?php if ($user['subscription_status'] === 'pending'): ?>
                                    <button name="action" value="approve" class="btn btn-sm btn-success me-1">Approve</button>
                                    <button name="action" value="cancel" class="btn btn-sm btn-danger me-1">Cancel</button>
                                <?php endif; ?>
                                <button name="action" value="edit" class="btn btn-sm btn-warning me-1">Save</button>
                                <button name="action" value="delete" class="btn btn-sm btn-outline-light" onclick="return confirm('Delete this user?')">Delete</button>
                            </td>
                        </form>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'partials/footer.php'; ?>
