<?php
$page_title = 'Contact Messages';
include 'partials/header.php';

// Mark message as read
if (isset($_GET['mark_read']) && is_numeric($_GET['mark_read'])) {
    $id = (int) $_GET['mark_read'];
    $stmt = $conn->prepare("UPDATE contact_messages SET is_read = 1 WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: view_messages.php");
    exit;
}

$messages = $conn->query("SELECT * FROM contact_messages ORDER BY submitted_at DESC");
?>

<div class="container py-4">
    <h1 class="h3 mb-4 fw-bold">📬 Inbox - Contact Messages</h1>

    <div class="list-group shadow-sm animate__animated animate__fadeIn">
        <?php if ($messages->num_rows > 0): ?>
            <?php while ($msg = $messages->fetch_assoc()): ?>
                <div class="list-group-item list-group-item-action <?= !$msg['is_read'] ? 'list-group-item-warning' : '' ?> border rounded-3 mb-3 p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-1"><?= htmlspecialchars($msg['subject']) ?></h5>
                        <small class="text-muted"><?= date("d M Y, h:i A", strtotime($msg['submitted_at'])) ?></small>
                    </div>
                    <p class="mb-2"><?= nl2br(htmlspecialchars($msg['message'])) ?></p>
                    <div class="d-flex justify-content-between align-items-center">
                        <small class="text-muted">From: <?= htmlspecialchars($msg['name']) ?> (<?= htmlspecialchars($msg['email']) ?>)</small>
                        <?php if (!$msg['is_read']): ?>
                            <a href="?mark_read=<?= $msg['id'] ?>" class="btn btn-sm btn-success">Mark as Read</a>
                        <?php else: ?>
                            <span class="badge bg-secondary">Read</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="text-center text-muted">No messages found.</div>
        <?php endif; ?>
    </div>
</div>

<?php include 'partials/footer.php'; ?>
