<?php
$page_title = 'Update Profile';
require_once '../includes/db_connect.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// --- FIX: Fetch the user's current data directly from the database ---
// This is more reliable than relying only on session data set at login.
$user_stmt = $conn->prepare("SELECT username, email FROM users WHERE id = ?");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$result = $user_stmt->get_result();
$user = $result->fetch_assoc();
$user_stmt->close();

// If for some reason the user doesn't exist in the DB, log them out.
if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}


// Handle form submission to update the username
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_username'])) {
    $new_username = trim($_POST['username']);
    if (empty($new_username)) {
        $error = "Username cannot be empty.";
    } elseif ($new_username === $user['username']) { // Compare with DB data
        $error = "This is already your current username.";
    } else {
        // Check if new username is already taken by another user
        $check_stmt = $conn->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $check_stmt->bind_param("si", $new_username, $user_id);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows > 0) {
            $error = "Username is already taken. Please choose another one.";
        } else {
            // Update the username in the database
            $update_stmt = $conn->prepare("UPDATE users SET username = ? WHERE id = ?");
            $update_stmt->bind_param("si", $new_username, $user_id);
            if ($update_stmt->execute()) {
                $_SESSION['username'] = $new_username; // Update session variable as well
                $user['username'] = $new_username; // Update local variable for immediate display
                $message = "Username updated successfully!";
            } else {
                $error = "Failed to update username.";
            }
            $update_stmt->close();
        }
        $check_stmt->close();
    }
}

include 'partials/header.php';
include 'partials/navbar.php';
?>
<main class="main-content-area auth-wrapper">
    <div class="col-11 col-md-6 col-lg-5">
        <div class="card shadow-lg border-0" data-aos="fade-up">
            <div class="card-body p-4 p-md-5">
                <h2 class="card-title text-center mb-4">Update Profile</h2>

                <?php if ($message): ?><div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
                <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

                <form method="POST" action="update_profile.php">
                    <div class="mb-3">
                        <label class="form-label">Email (Cannot be changed)</label>
                        <!-- This now uses the email fetched directly from the database -->
                        <input type="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" id="username" name="username" placeholder="New Username" required value="<?php echo htmlspecialchars($user['username']); ?>">
                        <label for="username">New Username</label>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" name="update_username" class="btn btn-primary">Save Changes</button>
                        <a href="settings.php" class="btn btn-outline-secondary">Back to Settings</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>
<?php include 'partials/footer.php'; ?>
