<?php
$page_title = 'Contact Us';
require_once '../includes/db_connect.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
include 'partials/header.php';
include 'partials/navbar.php';
?>

<!-- Success Popup CSS (already optimized) -->
<style>
/* ... [your success modal CSS unchanged here] ... */
</style>

<!-- Hero Section -->
<div class="hero-section text-white text-center">
    <div class="container" data-aos="fade-up">
        <h1 class="display-4">Get In Touch</h1>
        <p class="lead">Have a question or feedback? We'd love to hear from you.</p>
    </div>
</div>

<!-- Contact Form -->
<main class="container main-content-area">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div id="contact-form-card" class="card shadow-lg border-0" data-aos="fade-up" data-aos-delay="100">
                <div class="card-body p-4 p-md-5">
                    <div id="contact-form-alert-area"></div>
                    <form id="contact-form">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required>
                                    <label for="name">Your Name</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="email" class="form-control" id="email" name="email" placeholder="Your Email" required>
                                    <label for="email">Your Email</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" required>
                                    <label for="subject">Subject</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea class="form-control" placeholder="Leave a message here" id="message" name="message" style="height: 150px" required></textarea>
                                    <label for="message">Message</label>
                                </div>
                            </div>
                        </div>
                        <div class="d-grid mt-4">
                            <button class="btn btn-primary btn-lg" type="submit" id="contact-submit-btn">
                                <span id="btn-text">Send Message</span>
                                <span id="btn-loader" class="spinner-border spinner-border-sm" style="display: none;"></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Success Animation Modal -->
<div id="success-animation-modal" class="success-modal-overlay">
    <div class="success-modal-card">
        <div class="success-icon"></div>
        <h2 class="success-title">Thank you!</h2>
        <p class="success-message">Your submission has been sent.</p>
    </div>
</div>

<!-- Animated Card Success Toast -->
<div id="card-success-toast" class="card-success-toast" style="display:none;">
    <span>✅ Message sent successfully!</span>
</div>

<!-- Add jQuery CDN -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<!-- JS Logic -->
<script>
$(document).ready(function() {
    // Animate form card on load
    $('#contact-form-card').hide().fadeIn(700);
    // Button hover/click animation
    $('#contact-submit-btn').on('mousedown', function() {
        $(this).css({transform: 'scale(0.97)'});
    }).on('mouseup mouseleave', function() {
        $(this).css({transform: 'scale(1)'});
    });

    // Improved form validation and AJAX
    $('#contact-form').on('submit', function (e) {
        e.preventDefault();
        const btn = $('#contact-submit-btn');
        const btnText = $('#btn-text');
        const btnLoader = $('#btn-loader');
        const alertArea = $('#contact-form-alert-area');
        let valid = true;
        alertArea.empty();
        // Field validation
        $(this).find('input, textarea').removeClass('is-invalid');
        const name = $('#name').val().trim();
        const email = $('#email').val().trim();
        const subject = $('#subject').val().trim();
        const message = $('#message').val().trim();
        if (!name) { $('#name').addClass('is-invalid'); valid = false; }
        if (!email || !/^\S+@\S+\.\S+$/.test(email)) { $('#email').addClass('is-invalid'); valid = false; }
        if (!subject) { $('#subject').addClass('is-invalid'); valid = false; }
        if (!message) { $('#message').addClass('is-invalid'); valid = false; }
        if (!valid) {
            alertArea.html('<div class="alert alert-danger">Please fill all fields correctly.</div>');
            return;
        }
        // Prevent double submit
        btn.prop('disabled', true);
        btnText.hide();
        btnLoader.show();
        const formData = new FormData(this);
        fetch('../api/send_contact_message.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                $('#contact-form')[0].reset();
                const modal = $('#success-animation-modal');
                modal.addClass('show');
                setTimeout(() => modal.removeClass('show'), 4000);
                // Show animated card success toast
                const toast = $('#card-success-toast');
                toast.show().addClass('show');
                setTimeout(() => { toast.removeClass('show'); setTimeout(() => toast.hide(), 400); }, 3000);
            } else {
                alertArea.html(`<div class="alert alert-danger">${data.error}</div>`);
            }
        })
        .catch(() => {
            alertArea.html('<div class="alert alert-danger">Something went wrong. Please try again later.</div>');
        })
        .finally(() => {
            btn.prop('disabled', false);
            btnText.show();
            btnLoader.hide();
        });
    });
});
</script>

<?php include 'partials/footer.php'; ?>
