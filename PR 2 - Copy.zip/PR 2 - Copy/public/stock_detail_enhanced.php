<?php
session_start();
$page_title = 'Stock Details - Enhanced';
require_once '../includes/db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$symbol = isset($_GET['symbol']) ? trim(strtoupper($_GET['symbol'])) : '';
if (empty($symbol)) {
    header("Location: stocklist.php");
    exit();
}

include 'partials/header.php';
include 'partials/navbar.php';
?>

<body data-stock-symbol="<?php echo htmlspecialchars($symbol); ?>">
<main class="main-content-area py-5">
    <div class="container-fluid">
        <!-- Header Section -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h1 class="h2 fw-bold text-primary">📈 <?php echo htmlspecialchars($symbol); ?> Stock Analysis</h1>
                        <p class="text-muted">Comprehensive stock analysis with AI predictions and technical charts</p>
                    </div>
                    <div>
                        <a href="dashboard.php" class="btn btn-outline-primary me-2">
                            <i class="fas fa-arrow-left"></i> Back to Dashboard
                        </a>
                        <button id="ai-analyze-btn" class="btn btn-success">
                            🤖 AI Analysis
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Loader -->
        <div id="loader" class="text-center p-5" data-aos="fade-in">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;"></div>
            <p class="mt-2 fw-semibold text-muted">Loading comprehensive stock analysis...</p>
        </div>

        <!-- Error Message -->
        <div id="error-msg" class="alert alert-danger mt-3" style="display:none;"></div>

        <!-- Main Content -->
        <div id="stock-detail-content" style="display:none;" data-aos="fade-up">
            
            <!-- Stock Overview Card -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card shadow-sm" id="stock-info-card">
                        <!-- JS will fill this -->
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="row g-4 mb-4">
                <!-- Price Chart -->
                <div class="col-lg-8">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0"><i class="fas fa-chart-line me-2"></i>Price Movement Chart</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="priceChart" height="300"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Technical Indicators -->
                <div class="col-lg-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-success text-white">
                            <h5 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Technical Indicators</h5>
                        </div>
                        <div class="card-body">
                            <div id="technicalIndicators">
                                <!-- JS will fill this -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Additional Charts Row -->
            <div class="row g-4 mb-4">
                <!-- Volume Chart -->
                <div class="col-lg-6">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-info text-white">
                            <h5 class="mb-0"><i class="fas fa-chart-area me-2"></i>Volume Analysis</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="volumeChart" height="250"></canvas>
                        </div>
                    </div>
                </div>

                <!-- RSI Chart -->
                <div class="col-lg-6">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-warning text-dark">
                            <h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i>RSI (Relative Strength Index)</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="rsiChart" height="250"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- AI Analysis and News Row -->
            <div class="row g-4">
                <!-- AI Analysis -->
                <div class="col-lg-6">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-dark text-white">
                            <h5 class="mb-0"><i class="fas fa-robot me-2"></i>AI Prediction Analysis</h5>
                        </div>
                        <div class="card-body" id="prediction-container">
                            <div class="text-center py-4">
                                <div class="spinner-border text-success"></div>
                                <p class="mt-2">Loading AI analysis...</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- News Section -->
                <div class="col-lg-6">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-secondary text-white">
                            <h5 class="mb-0"><i class="fas fa-newspaper me-2"></i>Latest News</h5>
                        </div>
                        <div class="card-body" id="news-list-container">
                            <div class="text-center py-4">
                                <div class="spinner-border text-primary"></div>
                                <p class="mt-2">Loading news...</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- AI Analysis Modal -->
<div class="modal fade" id="analysis-modal" tabindex="-1" aria-labelledby="analysisModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content shadow-lg">
            <div class="modal-header">
                <h5 class="modal-title" id="analysis-modal-title">AI Analysis & News</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-6" id="modal-prediction-container">
                        <!-- JS will inject AI analysis here -->
                    </div>
                    <div class="col-lg-6 border-start">
                         <h5 class="mb-3">Latest News</h5>
                         <div id="modal-news-list-container">
                            <!-- JS will inject news here -->
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Enhanced JavaScript for Charts -->
<script>
$(document).ready(function() {
    const symbol = '<?php echo htmlspecialchars($symbol); ?>';
    const API_BASE_URL = '../api/';
    
    // Load stock data and initialize charts
    loadStockDataAndCharts(symbol);
    
    // AI Analysis button handler
    $('#ai-analyze-btn').on('click', function() {
        openAnalysisModal({ symbol: symbol, btn: $(this) });
    });
    
    function loadStockDataAndCharts(symbol) {
        $('#loader').show();
        $('#stock-detail-content').hide();
        
        // Fetch stock data
        $.getJSON(`${API_BASE_URL}get_stock_data.php?symbol=${encodeURIComponent(symbol)}`)
            .done(function(data) {
                $('#loader').hide();
                if (data && data.symbol) {
                    updateStockUI(data, '#stock-info-card');
                    $('#stock-detail-content').show();
                    
                    // Initialize charts with mock data (since we don't have historical data)
                    initializeCharts(data);
                    loadTechnicalIndicators(data);
                    loadAIAnalysis(symbol);
                    loadNews(symbol);
                } else {
                    showError(data.error || 'Failed to load stock data');
                }
            })
            .fail(function(xhr) {
                $('#loader').hide();
                showError('Failed to load stock data. Please try again.');
            });
    }
    
    function updateStockUI(data, containerId) {
        let price = (data.price && data.price !== 'N/A') ? data.price : (data.close_price && data.close_price !== 'N/A' ? data.close_price : 'N/A');
        let change = (data.change && data.change !== 'N/A') ? data.change : (data.price_change && data.price_change !== 'N/A' ? data.price_change : 'N/A');
        let change_percent = (data.change_percent && data.change_percent !== 'N/A') ? data.change_percent : 'N/A';
        let open = (data.open && data.open !== 'N/A') ? data.open : '—';
        let high = (data.high && data.high !== 'N/A') ? data.high : '—';
        let low = (data.low && data.low !== 'N/A') ? data.low : '—';
        let volume = (data.volume && data.volume !== 'N/A') ? data.volume : '—';
        let last_refreshed = (data.last_refreshed && data.last_refreshed !== 'N/A') ? data.last_refreshed : 'Live data';
        let note = data.note || '';
        
        if (price === 'N/A') {
            $(containerId).html(`
                <div class="card-body">
                    <div class="text-center py-4">
                        <h3 class="text-muted">No live data available for ${data.symbol}</h3>
                        <p class="text-muted">This stock may not be actively traded or data source is unavailable.</p>
                    </div>
                </div>
            `);
            return;
        }
        
        const isPositive = !isNaN(parseFloat(change)) && parseFloat(change) >= 0;
        const stockDetailsHtml = `
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="d-flex align-items-center mb-3">
                            <h2 class="mb-0 me-3">${data.symbol}</h2>
                            <span class="badge bg-${isPositive ? 'success' : 'danger'} fs-6">
                                ${isPositive ? '▲' : '▼'} ${change_percent}%
                            </span>
                        </div>
                        <h3 class="fw-bold text-primary mb-2">₹${price}</h3>
                        <p class="text-muted mb-0">Last updated: ${last_refreshed}</p>
                        ${note ? `<small class="text-muted d-block">${note}</small>` : ''}
                    </div>
                    <div class="col-md-6">
                        <div class="row text-center">
                            <div class="col-4">
                                <div class="border-end">
                                    <h6 class="text-muted mb-1">Open</h6>
                                    <h5 class="fw-bold">₹${open}</h5>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="border-end">
                                    <h6 class="text-muted mb-1">High</h6>
                                    <h5 class="fw-bold text-success">₹${high}</h5>
                                </div>
                            </div>
                            <div class="col-4">
                                <h6 class="text-muted mb-1">Low</h6>
                                <h5 class="fw-bold text-danger">₹${low}</h5>
                            </div>
                        </div>
                        <div class="row text-center mt-3">
                            <div class="col-12">
                                <h6 class="text-muted mb-1">Volume</h6>
                                <h5 class="fw-bold">${volume}</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        $(containerId).html(stockDetailsHtml);
    }
    
    function initializeCharts(data) {
        // Generate mock historical data for demonstration
        const days = 30;
        const basePrice = parseFloat(data.price.replace(/,/g, ''));
        const prices = [];
        const volumes = [];
        const rsiValues = [];
        const labels = [];
        
        for (let i = days - 1; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
            
            // Generate realistic price movement
            const volatility = 0.02; // 2% daily volatility
            const randomChange = (Math.random() - 0.5) * volatility;
            const newPrice = basePrice * (1 + randomChange);
            prices.push(newPrice);
            
            // Generate volume data
            const baseVolume = parseFloat(data.volume.replace(/,/g, '')) || 1000000;
            const volumeVariation = 0.3; // 30% volume variation
            const randomVolume = baseVolume * (0.7 + Math.random() * volumeVariation);
            volumes.push(randomVolume);
            
            // Generate RSI values (30-70 range)
            const rsi = 30 + Math.random() * 40;
            rsiValues.push(rsi);
        }
        
        // Price Chart
        const priceCtx = document.getElementById('priceChart').getContext('2d');
        new Chart(priceCtx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Price (₹)',
                    data: prices,
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 3,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        grid: { color: 'rgba(0,0,0,0.1)' }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
        
        // Volume Chart
        const volumeCtx = document.getElementById('volumeChart').getContext('2d');
        new Chart(volumeCtx, {
            type: 'bar',
            data: {
                labels: labels.slice(-10), // Last 10 days
                datasets: [{
                    label: 'Volume',
                    data: volumes.slice(-10),
                    backgroundColor: 'rgba(13, 202, 240, 0.6)',
                    borderColor: '#0dcaf0',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(0,0,0,0.1)' }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
        
        // RSI Chart
        const rsiCtx = document.getElementById('rsiChart').getContext('2d');
        new Chart(rsiCtx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'RSI',
                    data: rsiValues,
                    borderColor: '#ffc107',
                    backgroundColor: 'rgba(255, 193, 7, 0.1)',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        min: 0,
                        max: 100,
                        grid: { color: 'rgba(0,0,0,0.1)' }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
    }
    
    function loadTechnicalIndicators(data) {
        const price = parseFloat(data.price.replace(/,/g, '')) || 0;
        const change = parseFloat(data.change.replace(/,/g, '')) || 0;
        const volume = parseFloat(data.volume.replace(/,/g, '')) || 0;
        
        // Calculate mock technical indicators
        const sma20 = price * (1 + (Math.random() - 0.5) * 0.05);
        const sma50 = price * (1 + (Math.random() - 0.5) * 0.08);
        const rsi = 30 + Math.random() * 40;
        const macd = (Math.random() - 0.5) * 2;
        
        const indicatorsHtml = `
            <div class="row g-3">
                <div class="col-6">
                    <div class="text-center p-3 border rounded">
                        <h6 class="text-muted mb-1">SMA 20</h6>
                        <h5 class="fw-bold text-primary">₹${sma20.toFixed(2)}</h5>
                    </div>
                </div>
                <div class="col-6">
                    <div class="text-center p-3 border rounded">
                        <h6 class="text-muted mb-1">SMA 50</h6>
                        <h5 class="fw-bold text-info">₹${sma50.toFixed(2)}</h5>
                    </div>
                </div>
                <div class="col-6">
                    <div class="text-center p-3 border rounded">
                        <h6 class="text-muted mb-1">RSI</h6>
                        <h5 class="fw-bold ${rsi > 70 ? 'text-danger' : rsi < 30 ? 'text-success' : 'text-warning'}">${rsi.toFixed(1)}</h5>
                    </div>
                </div>
                <div class="col-6">
                    <div class="text-center p-3 border rounded">
                        <h6 class="text-muted mb-1">MACD</h6>
                        <h5 class="fw-bold ${macd > 0 ? 'text-success' : 'text-danger'}">${macd.toFixed(2)}</h5>
                    </div>
                </div>
            </div>
        `;
        
        $('#technicalIndicators').html(indicatorsHtml);
    }
    
    function loadAIAnalysis(symbol) {
        $.getJSON(`${API_BASE_URL}get_prediction.php?symbol=${encodeURIComponent(symbol)}`)
            .done(function(data) {
                if (data.error) {
                    $('#prediction-container').html(`<div class="alert alert-danger">${data.error}</div>`);
                    return;
                }
                
                let html = '';
                if (data.signal) {
                    const signalColor = data.signal.includes('Buy') ? 'success' : data.signal.includes('Sell') ? 'danger' : 'secondary';
                    html = `
                        <div class="text-center mb-3">
                            <h4 class="fw-bold">AI Signal</h4>
                            <span class="badge bg-${signalColor} fs-5 px-4 py-2">${data.signal}</span>
                        </div>
                        <div class="row g-3 mb-3">
                            <div class="col-4">
                                <div class="text-center">
                                    <h6 class="text-muted">Buy</h6>
                                    <h5 class="fw-bold text-success">${data.buy_probability}%</h5>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="text-center">
                                    <h6 class="text-muted">Sell</h6>
                                    <h5 class="fw-bold text-danger">${data.sell_probability}%</h5>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="text-center">
                                    <h6 class="text-muted">Hold</h6>
                                    <h5 class="fw-bold text-secondary">${data.hold_probability || (100 - data.buy_probability - data.sell_probability)}%</h5>
                                </div>
                            </div>
                        </div>
                        <div class="alert alert-info">
                            <strong>Analysis:</strong> ${data.reason || 'AI analysis based on technical indicators and market patterns.'}
                        </div>
                    `;
                } else {
                    html = '<div class="alert alert-warning">No prediction available.</div>';
                }
                $('#prediction-container').html(html);
            })
            .fail(function() {
                $('#prediction-container').html('<div class="alert alert-danger">Failed to load AI analysis.</div>');
            });
    }
    
    function loadNews(symbol) {
        $.getJSON(`${API_BASE_URL}get_stock_news.php?symbol=${encodeURIComponent(symbol)}`)
            .done(function(data) {
                if (data && data.news && data.news.length > 0) {
                    let newsHtml = '<div class="list-group list-group-flush">';
                    data.news.slice(0, 5).forEach(function(item) {
                        newsHtml += `
                            <div class="list-group-item border-0 px-0">
                                <h6 class="mb-1">
                                    <a href="${item.url}" target="_blank" class="text-decoration-none">${item.title}</a>
                                </h6>
                                <small class="text-muted">${item.source} • ${item.published_date}</small>
                            </div>
                        `;
                    });
                    newsHtml += '</div>';
                    $('#news-list-container').html(newsHtml);
                } else {
                    $('#news-list-container').html('<div class="alert alert-warning">No news available.</div>');
                }
            })
            .fail(function() {
                $('#news-list-container').html('<div class="alert alert-danger">Failed to load news.</div>');
            });
    }
    
    function openAnalysisModal({ symbol, btn }) {
        var $modal = $('#analysis-modal');
        $modal.modal('show');
        if (btn) {
            btn.prop('disabled', true);
            btn.html('<span class="spinner-border spinner-border-sm me-2"></span>Analyzing...');
        }
        
        // Load AI analysis for modal
        $.getJSON(`${API_BASE_URL}get_prediction.php?symbol=${encodeURIComponent(symbol)}`)
            .done(function(data) {
                if (data.error) {
                    $('#modal-prediction-container').html(`<div class="alert alert-danger">${data.error}</div>`);
                    return;
                }
                
                let html = '';
                if (data.signal) {
                    const signalColor = data.signal.includes('Buy') ? 'success' : data.signal.includes('Sell') ? 'danger' : 'secondary';
                    html = `
                        <div class="text-center mb-3">
                            <h4 class="fw-bold">AI Signal</h4>
                            <span class="badge bg-${signalColor} fs-5 px-4 py-2">${data.signal}</span>
                        </div>
                        <div class="row g-3 mb-3">
                            <div class="col-4">
                                <div class="text-center">
                                    <h6 class="text-muted">Buy</h6>
                                    <h5 class="fw-bold text-success">${data.buy_probability}%</h5>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="text-center">
                                    <h6 class="text-muted">Sell</h6>
                                    <h5 class="fw-bold text-danger">${data.sell_probability}%</h5>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="text-center">
                                    <h6 class="text-muted">Hold</h6>
                                    <h5 class="fw-bold text-secondary">${data.hold_probability || (100 - data.buy_probability - data.sell_probability)}%</h5>
                                </div>
                            </div>
                        </div>
                        <div class="alert alert-info">
                            <strong>Analysis:</strong> ${data.reason || 'AI analysis based on technical indicators and market patterns.'}
                        </div>
                    `;
                } else {
                    html = '<div class="alert alert-warning">No prediction available.</div>';
                }
                $('#modal-prediction-container').html(html);
            })
            .fail(function() {
                $('#modal-prediction-container').html('<div class="alert alert-danger">Failed to load AI analysis.</div>');
            });
        
        // Load news for modal
        $.getJSON(`${API_BASE_URL}get_stock_news.php?symbol=${encodeURIComponent(symbol)}`)
            .done(function(data) {
                if (data && data.news && data.news.length > 0) {
                    let newsHtml = '<div class="list-group list-group-flush">';
                    data.news.slice(0, 5).forEach(function(item) {
                        newsHtml += `
                            <div class="list-group-item border-0 px-0">
                                <h6 class="mb-1">
                                    <a href="${item.url}" target="_blank" class="text-decoration-none">${item.title}</a>
                                </h6>
                                <small class="text-muted">${item.source} • ${item.published_date}</small>
                            </div>
                        `;
                    });
                    newsHtml += '</div>';
                    $('#modal-news-list-container').html(newsHtml);
                } else {
                    $('#modal-news-list-container').html('<div class="alert alert-warning">No news available.</div>');
                }
            })
            .fail(function() {
                $('#modal-news-list-container').html('<div class="alert alert-danger">Failed to load news.</div>');
            });
        
        // Restore button state when modal is hidden
        $modal.on('hidden.bs.modal', function() {
            if (btn) {
                btn.prop('disabled', false);
                btn.html('🤖 AI Analysis');
            }
        });
    }
    
    function showError(message) {
        $('#loader').hide();
        $('#stock-detail-content').hide();
        $('#error-msg').text(message).show();
    }
});
</script>

<?php include 'partials/footer.php'; ?>
</body>
</html> 