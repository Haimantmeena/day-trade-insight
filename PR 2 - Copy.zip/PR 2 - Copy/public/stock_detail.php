<?php
session_start();
$page_title = 'Stock Details';
require_once '../includes/db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// URL से स्टॉक प्रतीक (symbol) प्राप्त करें और उसे साफ करें
$symbol = isset($_GET['symbol']) ? trim(strtoupper($_GET['symbol'])) : '';
if (empty($symbol)) {
    // यदि कोई प्रतीक नहीं है, तो उपयोगकर्ता को स्टॉक सूची पर वापस भेजें
    header("Location: stocklist.php");
    exit();
}

include 'partials/header.php';
include 'partials/navbar.php';
?>

<!-- body टैग में data-stock-symbol जोड़ना महत्वपूर्ण है ताकि main.js इसे पहचान सके -->
<body data-stock-symbol="<?php echo htmlspecialchars($symbol); ?>">
<main class="main-content-area py-5">
    <div class="container">
        <!-- Loader: जब तक डेटा लोड नहीं हो जाता, तब तक यह दिखाई देगा -->
        <div id="loader" class="text-center p-5" data-aos="fade-in">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;"></div>
            <p class="mt-2 fw-semibold text-muted">Loading live stock details...</p>
        </div>

        <!-- Error Message: यदि कोई त्रुटि होती है, तो यह दिखाई देगा -->
        <div id="error-msg" class="alert alert-danger mt-3" style="display:none;"></div>

        <!-- Stock Content: डेटा सफलतापूर्वक लोड होने के बाद यह दिखाई देगा -->
        <div id="stock-detail-content" style="display:none;" data-aos="fade-up">
            <div class="row g-4">
                <!-- Left Column for Stock Info and AI Button -->
                <div class="col-lg-7">
                    <!-- यह कार्ड JS द्वारा स्टॉक की कीमत, बदलाव आदि से भरा जाएगा -->
                    <div class="card shadow-sm mb-4" id="stock-info-card">
                        <!-- JS will fill this -->
                    </div>
                    <!-- AI Analyze बटन अब main.js द्वारा नियंत्रित किया जाएगा -->
                    <div class="d-grid mb-4">
                        <button id="ai-analyze-btn" class="btn btn-lg btn-success shadow-sm">
                            🤖 Run AI Analysis & View News
                        </button>
                    </div>
                </div>
                <!-- Right Column for Company Overview -->
                <div class="col-lg-5">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <h5 class="card-title mb-3">📄 Company Overview</h5>
                            <!-- यह div JS द्वारा कंपनी के विवरण से भरा जाएगा -->
                            <div id="company-overview-content">
                                <!-- JS will fill this with a loader first, then content -->
                                <div class="text-center">
                                    <div class="spinner-border spinner-border-sm text-secondary" role="status"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Modal for showing analysis and News (यह stocklist.php जैसा ही है) -->
<div class="modal fade" id="analysis-modal" tabindex="-1" aria-labelledby="analysisModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="analysis-modal-title">AI Analysis & News</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-6" id="prediction-container">
                        <!-- JS will inject AI analysis here -->
                    </div>
                    <div class="col-lg-6 border-start">
                         <h5 class="mb-3">Latest News</h5>
                         <div id="news-list-container">
                            <!-- JS will inject news here -->
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
// फुटर शामिल करें, जिसमें main.js भी है
include 'partials/footer.php'; 
?>
<!-- इस पेज से सभी इनलाइन <script> टैग हटा दिए गए हैं -->
</body>
