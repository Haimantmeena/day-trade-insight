<?php
$page_title = 'Settings';
require_once '../includes/db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT username, email, subscription_status FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}

include 'partials/header.php';
include 'partials/navbar.php';
?>

<!-- Hero Banner -->
<div class="hero-section text-white text-center py-5">
    <div class="container" data-aos="fade-down">
        <h1 class="display-4 fw-bold">Account Settings</h1>
        <p class="lead">Manage your profile, password, and premium subscription here.</p>
    </div>
</div>

<main class="container main-content-area">
    <!-- JS Alert Inject Area -->
    <div id="settings-alert-area" class="row justify-content-center mb-4">
        <div class="col-lg-10"></div>
    </div>

    <div class="row g-4 justify-content-center">
        <!-- Profile -->
        <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="card h-100 text-center setting-card shadow-sm">
                <div class="card-body d-flex flex-column">
                    <i class="bi bi-person-circle display-3 text-primary mb-3"></i>
                    <h5 class="card-title">👤 Profile</h5>
                    <p class="card-text">Update your username and view your email address.</p>
                    <div class="mt-auto">
                        <a href="update_profile.php" class="btn btn-outline-primary rounded-pill shadow-sm">Update Profile</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Password -->
        <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="card h-100 text-center setting-card shadow-sm">
                <div class="card-body d-flex flex-column">
                    <i class="bi bi-key-fill display-3 text-primary mb-3"></i>
                    <h5 class="card-title">🔐 Security</h5>
                    <p class="card-text">Change your password to enhance security.</p>
                    <div class="mt-auto">
                        <a href="update_password.php" class="btn btn-outline-primary rounded-pill shadow-sm">Change Password</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Subscription -->
        <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="300">
            <div class="card h-100 text-center setting-card shadow-sm">
                <div class="card-body d-flex flex-column">
                    <i class="bi bi-gem display-3 text-primary mb-3"></i>
                    <h5 class="card-title">💎 Subscription</h5>
                    <p>Your current status: 
                        <span class="badge bg-<?php echo $user['subscription_status'] === 'premium' ? 'success' : ($user['subscription_status'] === 'pending' ? 'warning text-dark' : 'secondary'); ?> fs-6">
                            <?php echo ucfirst($user['subscription_status']); ?>
                        </span>
                    </p>

                    <div class="mt-auto" id="subscription-action-area">
                        <?php if ($user['subscription_status'] === 'free'): ?>
                            <button id="request-premium-btn" class="btn btn-success rounded-pill shadow-sm">Request Premium Access</button>
                        <?php elseif ($user['subscription_status'] === 'pending'): ?>
                            <p class="text-muted">Your premium request is <strong>pending</strong> approval.</p>
                        <?php else: ?>
                            <p class="text-success fw-semibold">🎉 You have full premium access!</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'partials/footer.php'; ?>
