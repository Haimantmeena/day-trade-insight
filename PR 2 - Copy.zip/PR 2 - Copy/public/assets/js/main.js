$(document).ready(function () {
    const API_BASE_URL = '../api/'; 
    let searchTimeout;
    let currentSymbol = '';

    // --- Logic for Dashboard Page (Stock Search) ---
    if ($('#company-symbol').length) {
        const symbolInput = $('#company-symbol');
        const searchResults = $('#search-results');
        const fetchBtn = $('#fetch-btn');
        
        // Search suggestions functionality
        symbolInput.on('keyup', function (e) {
            if (e.key === 'Enter') {
                fetchBtn.click();
                return;
            }
            clearTimeout(searchTimeout);
            const keywords = $(this).val().trim();
            if (keywords.length < 2) {
                searchResults.hide().empty();
                $('#search-suggestions').remove();
                return;
            }
            searchTimeout = setTimeout(() => {
                // Get search suggestions
                $.getJSON(`${API_BASE_URL}search_suggestions.php`, { q: keywords })
                    .done(data => {
                        $('#search-suggestions').remove();
                        if (data.suggestions && data.suggestions.length > 0) {
                            let suggestionsHtml = '<div id="search-suggestions" class="mt-3"><div class="container-fluid">';
                            suggestionsHtml += '<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">';
                            
                            data.suggestions.forEach(suggestion => {
                                suggestionsHtml += `
                                <div class="col">
                                    <div class="card h-100 shadow-sm suggestion-card" 
                                         data-symbol="${suggestion.symbol}"
                                         style="cursor: pointer; transition: all 0.3s ease;">
                                        <div class="card-body p-3">
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <h6 class="card-title fw-bold mb-0">${suggestion.symbol}</h6>
                                                <span class="badge bg-primary">Click to Load</span>
                                            </div>
                                            <p class="card-text small text-muted mb-0">${suggestion.company}</p>
                                        </div>
                                    </div>
                                </div>
                                `;
                            });
                            suggestionsHtml += '</div></div></div>';
                            $(searchResults).after(suggestionsHtml);
                            
                            // Add hover effects
                            $('.suggestion-card').hover(
                                function() { $(this).addClass('shadow-lg').css('transform', 'translateY(-2px)'); },
                                function() { $(this).removeClass('shadow-lg').css('transform', 'translateY(0)'); }
                            );
                        } else {
                            searchResults.html('<span class="list-group-item disabled">No suggestions found</span>').show();
                        }
                    })
                    .fail(xhr => {
                        searchResults.html('<span class="list-group-item disabled">Search suggestions unavailable</span>').show();
                    });
            }, 300);
        });

        // Handle clicks on suggestion cards
        $(document).on('click', '.suggestion-card', function (e) {
            e.preventDefault();
            const exactSymbol = $(this).data('symbol');
            console.log('Clicked suggestion symbol:', exactSymbol); // Debug log
            
            if (!exactSymbol) {
                console.error('No symbol found in clicked element');
                showToast('Error: No stock symbol found', 'error');
                return;
            }
            
            symbolInput.val(exactSymbol); // Update input with selected symbol
            $('#search-suggestions').remove();
            searchResults.hide().empty();
            
            console.log('Fetching stock data for:', exactSymbol); // Debug log
            fetchStockData(exactSymbol);
        });

        // Handle clicks on old list items (for backward compatibility)
        searchResults.on('click', '.list-group-item-action', function (e) {
            e.preventDefault();
            const exactSymbol = $(this).data('symbol');
            console.log('Clicked stock symbol:', exactSymbol); // Debug log
            
            if (!exactSymbol) {
                console.error('No symbol found in clicked element');
                showToast('Error: No stock symbol found', 'error');
                return;
            }
            
            symbolInput.val(exactSymbol); // Update input with selected symbol
            searchResults.hide().empty();
            
            console.log('Fetching stock data for:', exactSymbol); // Debug log
            fetchStockData(exactSymbol);
        });

        fetchBtn.on('click', () => {
            const symbol = symbolInput.val().trim().toUpperCase();
            if (symbol) {
                searchResults.hide().empty();
                fetchStockData(symbol);
            }
        });
        
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.card-body').length) {
                searchResults.hide().empty();
            }
        });
    }

    // --- Top Stocks Page: Real-time filter for stock cards ---
    if ($('#stocklist-search').length) {
        $('#stocklist-search').on('input', function() {
            const query = $(this).val().toLowerCase();
            $('#stock-card-container .col').each(function() {
                const symbol = $(this).find('.stock-card').data('symbol')?.toString().toLowerCase() || '';
                const name = $(this).find('.stock-card').data('company_name')?.toString().toLowerCase() || '';
                if (symbol.includes(query) || name.includes(query)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });
    }

function fetchStockData(symbol) {
        console.log('fetchStockData called with:', symbol); // Debug log
        currentSymbol = symbol;
        
        // Hide elements that might not exist
        $('#welcome-prompt, #main-content-results, #error-msg').hide();
        $('#loader').show();
        // Hide news card while loading
        $('#main-news-card').hide();
        $('#main-news-list-container').empty();

        const apiUrl = `${API_BASE_URL}get_stock_data.php?symbol=${encodeURIComponent(symbol)}`;
        console.log('API URL:', apiUrl); // Debug log

        $.getJSON(apiUrl)
            .done(data => {
                console.log('API response:', data); // Debug log
                $('#loader').hide();
                setButtonLoading($('#fetch-btn'), false);
                if (data && data.symbol) {
                    updateStockUI(data, '#stock-info-card');
                    $('#main-content-results').show();
                    // Show source information
                    if (data.source === 'fallback') {
                        showToast('Using fallback data. Web scraping may be unavailable.', 'warning');
                    } else if (data.source === 'database') {
                        showToast('Data from local database. No live prices available.', 'info');
                    } else if (data.source === 'web_scraping') {
                        showToast('Live data from web scraping.', 'success');
                    } else {
                        showToast('Data loaded successfully.', 'success');
                    }
                    // Fetch and show news for this stock
                    fetchAndShowMainNews(symbol);
                } else if (data.error && data.suggestion) {
                    // Handle Indian stock error with suggestion
                    showError(`${data.error} 💡 ${data.suggestion}`);
                } else {
                    showError(data.error || 'Invalid data received.');
                }
            })
            .fail(err => {
                console.error('API request failed:', err); // Debug log
                $('#loader').hide();
                setButtonLoading($('#fetch-btn'), false);
                let errorMsg = err.responseJSON?.error || "Failed to load stock data.";
                showError(errorMsg);
            });
    }

// Fetch and display news in the main results area
function fetchAndShowMainNews(symbol) {
    $('#main-news-card').hide();
    $('#main-news-list-container').html('<div class="text-center py-3"><div class="spinner-border text-primary"></div></div>');
    $.getJSON('../api/get_stock_news.php', { symbol })
        .done(function (data) {
            let newsArr = [];
            if (data && data.news && Array.isArray(data.news)) {
                newsArr = data.news;
            } else if (Array.isArray(data)) {
                newsArr = data;
            }
            if (newsArr.length) {
                let newsHtml = '<ul class="list-group">';
                // Show only the latest news if that's all that's available
                newsArr.slice(0, 5).forEach(function (item) {
                    // Support both fallback and real news fields
                    const title = item.title || item.headline || 'News';
                    const url = item.url && item.url !== '#' ? item.url : null;
                    const summary = item.summary || item.description || '';
                    const published = item.published_date || item.published_at || '';
                    const source = item.source || '';
                    newsHtml += `<li class=\"list-group-item\">
                        ${url ? `<a href=\"${url}\" target=\"_blank\" rel=\"noopener\">${title}</a>` : `<span>${title}</span>`}
                        <div class=\"small text-muted\">${source}${published ? ' · ' + published : ''}</div>
                        ${summary ? `<div class=\"small text-secondary mt-1\">${summary}</div>` : ''}
                    </li>`;
                });
                newsHtml += '</ul>';
                $('#main-news-list-container').html(newsHtml);
                $('#main-news-card').fadeIn();
            } else {
                $('#main-news-list-container').html('<div class="alert alert-warning">No news found for this stock.</div>');
                $('#main-news-card').fadeIn();
            }
        })
        .fail(function () {
            $('#main-news-list-container').html('<div class="alert alert-danger">Failed to load news.</div>');
            $('#main-news-card').fadeIn();
        });
}

    // --- Toast Notification Utility ---
    function showToast(message, type = 'info') {
        if (!$('#custom-toast-container').length) {
            $('body').append('<div id="custom-toast-container"></div>');
        }
        const toastId = 'toast-' + Date.now();
        const toast = $(`<div class="custom-toast ${type}" id="${toastId}">${message}</div>`);
        $('#custom-toast-container').append(toast);
        setTimeout(() => toast.addClass('show'), 100);
        setTimeout(() => {
            toast.removeClass('show');
            setTimeout(() => toast.remove(), 400);
        }, 3200);
    }

    // Show toast on error
    function showError(message) {
        $('#loader').hide();
        $('#main-content-results').hide();
        $('#error-msg').text(message).show();
        showToast(message, 'error');
    }

    function updateStockUI(data, containerId) {
        console.log('updateStockUI called with:', data, containerId); // Debug log
        // Use close_price if price is missing or N/A
        let price = (data.price && data.price !== 'N/A') ? data.price : (data.close_price && data.close_price !== 'N/A' ? data.close_price : 'N/A');
        let change = (data.change && data.change !== 'N/A') ? data.change : (data.price_change && data.price_change !== 'N/A' ? data.price_change : 'N/A');
        let change_percent = (data.change_percent && data.change_percent !== 'N/A') ? data.change_percent : 'N/A';
        let open = (data.open && data.open !== 'N/A') ? data.open : '—';
        let high = (data.high && data.high !== 'N/A') ? data.high : '—';
        let low = (data.low && data.low !== 'N/A') ? data.low : '—';
        let volume = (data.volume && data.volume !== 'N/A') ? data.volume : '—';
        let last_refreshed = (data.last_refreshed && data.last_refreshed !== 'N/A') ? data.last_refreshed : 'Live data';
        let name = data.name || data.company_name || 'N/A';
        let note = data.note || '';
        
        if (price === 'N/A') {
            const stockDetailsHtml = `
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div><h2 class="mb-0">${data.symbol}</h2><small class="text-muted">${name}</small></div>
                        <div class="text-end"><h2 class="mb-0">N/A</h2><p class="mb-0 text-muted">No live data</p></div>
                    </div>
                    <div class="row text-center gy-2"><div class="col-12"><strong>Note:</strong> This stock is from the local database. No live price data available.</div></div>
                </div>`;
            $(containerId).html(stockDetailsHtml);
            $('#main-content-results').removeClass('d-none').show();
            return;
        }
        
        const isPositive = !isNaN(parseFloat(change)) && parseFloat(change) >= 0;
        const stockDetailsHtml = `
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div><h2 class="mb-0">${data.symbol}</h2><small class="text-muted">${last_refreshed}</small></div>
                    <div class="text-end"><h2 class="mb-0">₹${price}</h2><p class="mb-0 ${isPositive ? 'text-success' : 'text-danger'}">${isPositive ? '▲' : '▼'} ${change} (${change_percent}%)</p></div>
                </div>
                <div class="row text-center gy-2">
                    <div class="col-6 col-md-3"><strong>Open:</strong> ₹${open}</div>
                    <div class="col-6 col-md-3"><strong>High:</strong> ₹${high}</div>
                    <div class="col-6 col-md-3"><strong>Low:</strong> ₹${low}</div>
                    <div class="col-6 col-md-3"><strong>Volume:</strong> ${volume}</div>
                </div>
                ${note ? `<div class="row mt-2"><div class="col-12"><small class="text-muted text-center d-block">${note}</small></div></div>` : ''}
            </div>`;
        $(containerId).html(stockDetailsHtml);
        $('#main-content-results').removeClass('d-none').show();
    }
    
    // --- Modal Cleanup: Remove lingering backdrops and reset body state ---
    $(document).on('hidden.bs.modal', '.modal', function () {
        if ($('.modal.show').length === 0) {
            $('body').removeClass('modal-open');
            $('.modal-backdrop').remove();
        }
    });

    // --- Make Top Stocks cards clickable ---
    $(document).on('click', '.stock-card.custom-card', function (e) {
        e.preventDefault();
        const symbol = $(this).data('symbol');
        const price = $(this).data('price');
        const change = $(this).data('change');
        const marketcap = $(this).data('marketcap');
        const companyName = $(this).data('company_name') || $(this).find('.card-subtitle').text();
        const foundedYear = $(this).data('founded_year') || '';
        const lastUpdated = $(this).data('date') || '';
        // Defensive formatting for DB search
        const priceDisplay = price && !isNaN(parseFloat(price)) ? `₹${parseFloat(price).toFixed(2)}` : 'N/A';
        const marketCapDisplay = marketcap && !isNaN(parseFloat(marketcap)) ? `₹${parseFloat(marketcap).toLocaleString()} Cr` : 'N/A';
        const isPositive = change && !isNaN(parseFloat(change)) ? parseFloat(change) >= 0 : false;
        const changeDisplay = change && !isNaN(parseFloat(change)) ? `${isPositive ? '▲' : '▼'} ₹${parseFloat(change).toFixed(2)}` : 'N/A';
        const lastUpdatedDisplay = lastUpdated && lastUpdated !== 'N/A' ? lastUpdated : 'N/A';
        const gradientClass = $(this).attr('class').split(' ').find(c => c.startsWith('gradient-')) || '';
        // Build the card HTML for the modal
        const cardHtml = `
            <div class=\"card h-100 shadow-sm stock-card modern custom-card animated-gradient ${gradientClass}\"
                data-symbol=\"${symbol}\" data-price=\"${price}\" data-change=\"${change}\" data-marketcap=\"${marketcap}\">
                <div class=\"card-body p-4\">
                    <div class=\"d-flex justify-content-between align-items-center mb-2\">
                        <h5 class=\"card-title fw-bold text-primary\">${symbol}</h5>
                        <span class=\"price-badge ${priceDisplay !== 'N/A' ? (isPositive ? 'text-success' : 'text-danger') : 'text-muted'}\">
                            ${priceDisplay !== 'N/A' ? changeDisplay : 'N/A'}
                        </span>
                    </div>
                    <p class=\"card-subtitle mb-3 text-muted\">${companyName}</p>
                    <div class=\"mb-2\">
                        <span class=\"marketcap-badge\">Market Cap: ${marketCapDisplay}</span>
                        <span class=\"founded-badge\">Founded: ${foundedYear || 'N/A'}</span>
                    </div>
                </div>
                <div class=\"card-footer bg-white border-0 d-flex justify-content-between align-items-center pt-3\">
                    <small class=\"text-muted\">Last Updated: ${lastUpdatedDisplay}</small>
                    <button class=\"btn ai-analyze-btn ai-analyze-stocklist-btn rounded-pill shadow-sm\">AI Analyze</button>
                </div>
            </div>
        `;
        $('#stock-detail-modal-body').html(cardHtml);
        const modal = new bootstrap.Modal(document.getElementById('stock-detail-modal'));
        modal.show();
    });

    // --- Make Top Stocks cards clickable (card-body fallback) ---
    $(document).on('click', '.stock-card.custom-card .card-body', function (e) {
        e.preventDefault();
        const card = $(this).closest('.stock-card.custom-card');
        const symbol = card.data('symbol');
        const price = card.data('price');
        const change = card.data('change');
        const marketcap = card.data('marketcap');
        const companyName = card.data('company_name') || card.find('.card-subtitle').text();
        const foundedYear = card.data('founded_year') || '';
        const lastUpdated = card.data('date') || '';
        // Defensive formatting for DB search
        const priceDisplay = price && !isNaN(parseFloat(price)) ? `₹${parseFloat(price).toFixed(2)}` : 'N/A';
        const marketCapDisplay = marketcap && !isNaN(parseFloat(marketcap)) ? `₹${parseFloat(marketcap).toLocaleString()} Cr` : 'N/A';
        const isPositive = change && !isNaN(parseFloat(change)) ? parseFloat(change) >= 0 : false;
        const changeDisplay = change && !isNaN(parseFloat(change)) ? `${isPositive ? '▲' : '▼'} ₹${parseFloat(change).toFixed(2)}` : 'N/A';
        const lastUpdatedDisplay = lastUpdated && lastUpdated !== 'N/A' ? lastUpdated : 'N/A';
        const gradientClass = card.attr('class').split(' ').find(c => c.startsWith('gradient-')) || '';
        const cardHtml = `
            <div class=\"card h-100 shadow-sm stock-card modern custom-card animated-gradient ${gradientClass}\"
                data-symbol=\"${symbol}\" data-price=\"${price}\" data-change=\"${change}\" data-marketcap=\"${marketcap}\">
                <div class=\"card-body p-4\">
                    <div class=\"d-flex justify-content-between align-items-center mb-2\">
                        <h5 class=\"card-title fw-bold text-primary\">${symbol}</h5>
                        <span class=\"price-badge ${priceDisplay !== 'N/A' ? (isPositive ? 'text-success' : 'text-danger') : 'text-muted'}\">
                            ${priceDisplay !== 'N/A' ? changeDisplay : 'N/A'}
                        </span>
                    </div>
                    <p class=\"card-subtitle mb-3 text-muted\">${companyName}</p>
                    <div class=\"mb-2\">
                        <span class=\"marketcap-badge\">Market Cap: ${marketCapDisplay}</span>
                        <span class=\"founded-badge\">Founded: ${foundedYear || 'N/A'}</span>
                    </div>
                </div>
                <div class=\"card-footer bg-white border-0 d-flex justify-content-between align-items-center pt-3\">
                    <small class=\"text-muted\">Last Updated: ${lastUpdatedDisplay}</small>
                    <button class=\"btn ai-analyze-btn ai-analyze-stocklist-btn rounded-pill shadow-sm\">AI Analyze</button>
                </div>
            </div>
        `;
        $('#stock-detail-modal-body').html(cardHtml);
        const modal = new bootstrap.Modal(document.getElementById('stock-detail-modal'));
        modal.show();
    });

    // --- AI Analyze button in details modal ---
    $(document).on('click', '#stock-detail-modal .ai-analyze-stocklist-btn', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const card = $(this).closest('.stock-card');
        const symbol = card.data('symbol');
        const price = card.data('price');
        const change = card.data('change');
        const marketcap = card.data('marketcap');
        // Hide the details modal before opening AI modal
        const detailModal = bootstrap.Modal.getInstance(document.getElementById('stock-detail-modal'));
        if (detailModal) detailModal.hide();
        setTimeout(function() {
            openAnalysisModal({ symbol, close_price: price, price_change: change, market_cap: marketcap, btn: $(this) });
        }, 300);
    });

    // --- AI Analyze Button on Top Stocks Card (one-click analyze) ---
    $(document).on('click', '.stock-card.custom-card .ai-analyze-stocklist-btn', function(e) {
        e.preventDefault();
        e.stopPropagation(); // Prevent card click from firing
        const card = $(this).closest('.stock-card.custom-card');
        const symbol = card.data('symbol');
        const price = card.data('price');
        const change = card.data('change');
        const marketcap = card.data('marketcap');
        openAnalysisModal({ symbol, close_price: price, price_change: change, market_cap: marketcap, btn: $(this) });
    });

    // --- Utility: Show/Hide Spinner on Button ---
    function setButtonLoading($btn, loading, text) {
        if (loading) {
            $btn.prop('disabled', true);
            $btn.data('original-text', $btn.html());
            $btn.html('<span class="spinner-border spinner-border-sm me-2"></span>' + (text || $btn.text()));
        } else {
            $btn.prop('disabled', false);
            if ($btn.data('original-text')) $btn.html($btn.data('original-text'));
        }
    }

    // --- AI Analyze Modal Logic (update to use spinner) ---
    function openAnalysisModal({ symbol, close_price, price_change, market_cap, btn }) {
        var $modal = $('#analysis-modal');
        $modal.modal('show');
        if (btn) setButtonLoading(btn, true, 'Analyzing...');
        $('#prediction-container').html('<div class="text-center py-5"><div class="spinner-border text-success" style="width: 3rem; height: 3rem;"></div><p class="mt-3 fw-semibold">Analyzing with AI...</p></div>');
        $('#news-list-container').html('<div class="text-center py-4"><div class="spinner-border text-primary"></div></div>');

        // Determine if this is a live or offline analysis
        let params = {};
        let isLive = false;
        
        // Check if we have valid price data (not N/A or null)
        const hasValidPrice = close_price && close_price !== 'N/A' && !isNaN(parseFloat(close_price));
        const hasValidChange = price_change && price_change !== 'N/A' && !isNaN(parseFloat(price_change));
        const hasValidMarketCap = market_cap && market_cap !== 'N/A' && !isNaN(parseFloat(market_cap));
        
        if (symbol && hasValidPrice && hasValidChange && hasValidMarketCap) {
            // We have all required data for offline analysis
            params = { symbol, close_price, price_change, market_cap };
            isLive = false;
        } else if (symbol) {
            // We have symbol but missing some data, use live analysis
            params = { symbol };
            isLive = true;
        } else {
            $('#prediction-container').html('<div class="alert alert-danger">Symbol is required for AI analysis.</div>');
            if (btn) setButtonLoading(btn, false);
            return;
        }

        // Fetch AI prediction
        $.getJSON('../api/get_prediction.php', params)
            .done(function (data) {
                if (data.error) {
                    $('#prediction-container').html('<div class="alert alert-danger">' + data.error + '</div>');
                    if (btn) setButtonLoading(btn, false);
                    return;
                }
                let html = '';
                if (data.signal) {
                    html += `<div class="ai-prediction-result">
                        <h4 class="fw-bold mb-3">AI Signal: <span class="badge bg-${data.signal.includes('Buy') ? 'success' : data.signal.includes('Sell') ? 'danger' : 'secondary'}">${data.signal}</span></h4>
                        <ul class="list-group mb-3">
                            <li class="list-group-item">Buy Probability: <strong>${data.buy_probability}%</strong></li>
                            <li class="list-group-item">Sell Probability: <strong>${data.sell_probability}%</strong></li>
                        </ul>
                        <div class="alert alert-info">${data.reason || ''}</div>
                    </div>`;
                } else {
                    html += `<div class="alert alert-warning">No prediction available.</div>`;
                }
                $('#prediction-container').html(html);
                if (btn) setButtonLoading(btn, false);
            })
            .fail(function (xhr) {
                let msg = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : 'AI analysis failed.';
                $('#prediction-container').html('<div class="alert alert-danger">' + msg + '</div>');
                if (btn) setButtonLoading(btn, false);
            });

        // Fetch news
        if (symbol) {
            $.getJSON('../api/get_stock_news.php', { symbol })
                .done(function (data) {
                    if (data && data.length) {
                        let newsHtml = '<ul class="list-group">';
                        data.forEach(function (item) {
                            newsHtml += `<li class="list-group-item">
                                <a href="${item.url}" target="_blank" rel="noopener">${item.title}</a>
                                <div class="small text-muted">${item.source} &middot; ${item.published_at}</div>
                            </li>`;
                        });
                        newsHtml += '</ul>';
                        $('#news-list-container').html(newsHtml);
                    } else {
                        $('#news-list-container').html('<div class="alert alert-warning">No news found.</div>');
                    }
                })
                .fail(function () {
                    $('#news-list-container').html('<div class="alert alert-danger">Failed to load news.</div>');
                });
        }
        // After AJAX completes (success or fail), restore button state:
        // function restoreAnalyzeBtns() { setButtonLoading($analyzeBtns, false); }
        // In .done and .fail of $.getJSON for prediction and news, call restoreAnalyzeBtns();
    }

    // --- Main AI Analyze Button Handler ---
    $(document).on('click', '#ai-analyze-btn', function (e) {
        e.preventDefault();
        // Try to get the current stock data from the visible card
        let card = $('#stock-info-card');
        let symbol = card.find('h2').first().text().trim();
        let price = card.find('.mb-0').eq(1).text().replace('₹', '').replace(/,/g, '').trim();
        let change = card.find('p').eq(0).text().replace(/[▲▼]/g, '').replace('%', '').trim();
        let marketcap = null;
        // Try to get market cap if available
        let marketcapText = card.find('.marketcap-badge').text();
        if (marketcapText) {
            marketcap = marketcapText.replace(/[^\d.]/g, '');
        }
        // Fallbacks for DB search minimal card
        if (!price || price === 'N/A') price = null;
        if (!change) change = null;
        if (!marketcap) marketcap = null;
        openAnalysisModal({ symbol, close_price: price, price_change: change, market_cap: marketcap, btn: $(this) });
    });

    // --- Main Search Button Spinner ---
    $('#fetch-btn').on('click', function() {
        var $btn = $(this);
        setButtonLoading($btn, true, 'Searching...');
        // After search completes (success or fail), call setButtonLoading($btn, false);
    });

    // --- Dark Mode Toggle ---
    const themeSwitcher = document.getElementById('theme-switcher');
    const htmlTag = document.documentElement;

    // Helper to set theme
    function setTheme(theme) {
        htmlTag.setAttribute('data-bs-theme', theme);
        if (themeSwitcher) themeSwitcher.checked = (theme === 'dark');
        localStorage.setItem('theme', theme);
    }

    // On page load, set theme from localStorage or default
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        setTheme(savedTheme);
    } else {
        setTheme(htmlTag.getAttribute('data-bs-theme') || 'light');
    }

    // Listen for toggle
    if (themeSwitcher) {
        themeSwitcher.addEventListener('change', function() {
            setTheme(this.checked ? 'dark' : 'light');
        });
    }

    // Floating Bird Widget
    const aiFaqData = [
      {q: "What is AI stock prediction?", a: "AI stock prediction uses machine learning models to forecast future stock prices or trends based on historical data, news, and other factors."},
      {q: "How accurate are AI stock predictions?", a: "Accuracy depends on data quality, model sophistication, and market volatility. AI can spot patterns humans miss, but no prediction is 100% certain."},
      {q: "How do I interpret buy/sell signals?", a: "A 'Buy' signal suggests the model expects the stock to rise, while a 'Sell' signal suggests a potential drop. Always consider other factors before acting."},
      {q: "Can AI predict stock market crashes?", a: "AI can sometimes detect early warning signs, but sudden crashes due to unforeseen events are hard to predict for any system."},
      {q: "What data does the AI use?", a: "It uses historical prices, volume, technical indicators, news sentiment, and sometimes macroeconomic data."},
      {q: "Is AI better than human analysts?", a: "AI can process vast data quickly and spot subtle patterns, but human intuition and experience are still valuable."},
      {q: "How often are predictions updated?", a: "Predictions are typically updated daily or in real-time, depending on the system and data availability."},
      {q: "Can I trust AI predictions for investing?", a: "AI is a helpful tool, but always use it alongside your own research and risk management."},
      {q: "What is a confidence score?", a: "A confidence score shows how certain the AI is about its prediction. Higher scores mean more confidence."},
      {q: "What is a buy probability?", a: "Buy probability is the AI's estimated chance that the stock will go up in the near future."},
      {q: "What is a sell probability?", a: "Sell probability is the AI's estimated chance that the stock will go down in the near future."},
      {q: "What is a hold signal?", a: "A hold signal means the AI expects little movement or is uncertain, so neither buy nor sell is strongly recommended."},
      {q: "How does the AI learn?", a: "The AI is trained on large datasets using machine learning algorithms, improving as it processes more data."},
      {q: "Can AI predict penny stocks?", a: "AI can analyze any stock, but low-volume or highly volatile stocks are harder to predict accurately."},
      {q: "Does AI consider news and events?", a: "Yes, advanced models analyze news sentiment and major events to adjust predictions."},
      {q: "Can I use AI for day trading?", a: "Some AI tools are designed for short-term trading, but always be cautious and test strategies first."},
      {q: "What is overfitting in AI models?", a: "Overfitting means the AI is too closely tuned to past data and may not generalize well to new situations."},
      {q: "How do I use AI predictions in my strategy?", a: "Use AI as one input among many—combine with technical, fundamental, and risk analysis."},
      {q: "Are AI predictions free?", a: "Some platforms offer free predictions, while others charge for advanced features or real-time data."},
      {q: "Can AI predict cryptocurrency prices?", a: "Yes, similar models can be used for crypto, but the markets are even more volatile."},
      {q: "What is a neural network?", a: "A neural network is a type of AI model inspired by the human brain, used for complex pattern recognition."},
      {q: "How do I know if a prediction is reliable?", a: "Check the model's past performance, confidence scores, and use your own judgment."},
      {q: "Can AI help with portfolio management?", a: "Yes, AI can suggest portfolio allocations, risk levels, and diversification strategies."},
      {q: "What is backtesting?", a: "Backtesting means testing a prediction model on past data to see how it would have performed."},
      {q: "Does AI replace financial advisors?", a: "AI is a tool to assist, not replace, human advisors. Use both for best results."},
      {q: "How do I get started with AI stock prediction?", a: "Explore platforms, read documentation, and start with small investments to learn."},
      {q: "What are the risks of using AI predictions?", a: "No prediction is perfect. Always manage risk and never invest more than you can afford to lose."},
      {q: "Can AI explain its predictions?", a: "Some models offer explanations, but many are 'black boxes.' Transparency is improving."},
      {q: "How do I switch between dark and light mode?", a: "Use the toggle in the FAQ panel or your site’s main theme switcher."},
      {q: "Where can I learn more about AI in finance?", a: "Check out reputable finance and AI blogs, online courses, and your platform’s help center."}
    ];

    function renderFaqList() {
      const faqList = document.querySelector('#ai-faq-panel .faq-list');
      faqList.innerHTML = '';
      aiFaqData.forEach((item, i) => {
        const faq = document.createElement('div');
        faq.className = 'faq-item';
        faq.innerHTML = `
          <div class="faq-q">${item.q}<span class="faq-toggle">&#9654;</span></div>
          <div class="faq-a">${item.a}</div>
        `;
        faq.addEventListener('click', function(e) {
          if (e.target.classList.contains('faq-toggle') || e.target.classList.contains('faq-q') || e.target === faq) {
            faq.classList.toggle('active');
          }
        });
        faqList.appendChild(faq);
      });
    }

    document.getElementById('ai-faq-bird-btn').onclick = function() {
      document.getElementById('ai-faq-panel').classList.add('active');
      renderFaqList();
    };
    document.getElementById('ai-faq-close').onclick = function() {
      document.getElementById('ai-faq-panel').classList.remove('active');
    };
    document.getElementById('ai-faq-theme-toggle').onclick = function() {
      const html = document.documentElement;
      const current = html.getAttribute('data-bs-theme');
      html.setAttribute('data-bs-theme', current === 'dark' ? 'light' : 'dark');
    };
    document.getElementById('ai-faq-chat-btn').onclick = function() {
      const msg = document.getElementById('ai-faq-chat-message');
      msg.style.display = msg.style.display === 'block' ? 'none' : 'block';
    };
});
