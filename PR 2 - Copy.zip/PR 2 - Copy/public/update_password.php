<?php
$page_title = 'Change Password';
require_once '../includes/db_connect.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
// ... (Your existing secure PHP logic for changing password)
include 'partials/header.php';
include 'partials/navbar.php';
?>
<main class="main-content-area auth-wrapper">
     <div class="col-11 col-md-6 col-lg-5">
        <div class="card shadow-lg border-0" data-aos="fade-up">
            <div class="card-body p-4 p-md-5">
                <h2 class="card-title text-center mb-4">Change Password</h2>
                <!-- Form for changing password -->
                <form>
                    <div class="form-floating mb-3">
                        <input type="password" class="form-control" id="current_password" name="current_password" placeholder="Current Password" required>
                        <label for="current_password">Current Password</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="password" class="form-control" id="new_password" name="new_password" placeholder="New Password" required>
                        <label for="new_password">New Password</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm New Password" required>
                        <label for="confirm_password">Confirm New Password</label>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Update Password</button>
                        <a href="settings.php" class="btn btn-outline-secondary">Back to Settings</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>
<?php include 'partials/footer.php'; ?>
