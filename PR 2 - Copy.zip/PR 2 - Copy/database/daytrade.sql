--
-- Database: `daytrade_db`
--

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `subscription_status` enum('free','premium') NOT NULL DEFAULT 'free',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Default admin user. Password is 'adminpassword'
--
INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `subscription_status`, `created_at`) VALUES
(1, 'admin', 'admin@daytrade.com', '$2y$10$E/feyc2xJ36t4L9d1d8L..dE9LALsL1k.oFv1s0GgqG1mYk7.zC/K', 'admin', 'premium', '2025-06-13 18:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(20) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `market_cap` decimal(20,2) DEFAULT NULL,
  `close_price` decimal(10,2) DEFAULT NULL,
  `price_change` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Example data for `stocks` table
--
INSERT INTO `stocks` (`symbol`, `company_name`, `market_cap`, `close_price`, `price_change`) VALUES
('RELIANCE', 'Reliance Industries Ltd.', 1950000.00, 2900.50, 25.50),
('TCS', 'Tata Consultancy Services Ltd.', 1400000.00, 3850.75, -10.20),
('HDFCBANK', 'HDFC Bank Ltd.', 1150000.00, 1550.00, 15.00),
('INFY', 'Infosys Ltd.', 650000.00, 1500.00, -5.75),
('ICICIBANK', 'ICICI Bank Ltd.', 600000.00, 1050.25, 8.10),
('HINDUNILVR', 'Hindustan Unilever Ltd.', 580000.00, 2500.00, 12.00),
('SBIN', 'State Bank of India', 520000.00, 600.50, 2.30),
('BHARTIARTL', 'Bharti Airtel Ltd.', 480000.00, 900.00, -1.50);

COMMIT;
