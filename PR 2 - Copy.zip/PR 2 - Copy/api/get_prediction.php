<?php
require_once __DIR__ . '/../includes/db_connect.php'; 
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) { 
    http_response_code(403); 
    echo json_encode(['error' => 'User not authenticated']);
    exit; 
}

$params = $_GET;

// Check if we have the required parameters
if (!isset($params['symbol'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Stock symbol is required.']);
    exit;
}

// --- AI API URL Setup ---
$python_api_url = "";
if (isset($params['symbol']) && !isset($params['close_price'])) {
    // LIVE Data request
    $python_api_url = "http://127.0.0.1:5000/predict_live";
} elseif (isset($params['close_price'])) {
    // OFFLINE DB Data request
    $python_api_url = "http://127.0.0.1:5000/predict_offline";
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid prediction parameters.']);
    exit;
}

// Try to connect to Python server
$ch = curl_init($python_api_url . "?" . http_build_query($params));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5); // Reduced timeout for faster fallback
$response = curl_exec($ch);

// Check if Python server is available
if (curl_errno($ch) || curl_getinfo($ch, CURLINFO_HTTP_CODE) >= 400) {
    curl_close($ch);
    
    // Provide mock AI prediction when Python server is not available
    $symbol = $params['symbol'];
    $signals = ['Buy', 'Sell', 'Hold'];
    $signal = $signals[array_rand($signals)];
    
    // Generate realistic probabilities
    $buy_prob = rand(20, 80);
    $sell_prob = rand(20, 80);
    $hold_prob = 100 - $buy_prob - $sell_prob;
    
    // Ensure probabilities add up to 100
    if ($hold_prob < 0) {
        $buy_prob = 40;
        $sell_prob = 30;
        $hold_prob = 30;
    }
    
    $reasons = [
        'Buy' => "Strong technical indicators suggest upward momentum. The stock shows positive trend patterns and favorable market conditions.",
        'Sell' => "Technical analysis indicates potential downward pressure. Consider reducing position size or taking profits.",
        'Hold' => "Mixed signals suggest sideways movement. Monitor for clearer direction before making significant moves."
    ];
    
    $mock_response = [
        'signal' => $signal,
        'buy_probability' => $buy_prob,
        'sell_probability' => $sell_prob,
        'hold_probability' => $hold_prob,
        'reason' => $reasons[$signal],
        'confidence' => rand(60, 90),
        'note' => 'This is a mock prediction. For real AI analysis, ensure the Python prediction server is running.'
    ];
    
    echo json_encode($mock_response);
    exit;
}

$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_code >= 400) { 
    http_response_code($http_code); 
}

echo $response;
?>
