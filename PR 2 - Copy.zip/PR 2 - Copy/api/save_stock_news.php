<?php
require_once '../includes/db_connect.php';
require_once '../includes/web_scraper.php';

// Get all stock symbols
$result = $conn->query("SELECT symbol, company_name FROM stocks");
if (!$result || $result->num_rows == 0) {
    die("No stock data found.");
}

global $webScraper;

while ($row = $result->fetch_assoc()) {
    $symbol = $row['symbol'];
    $company = $row['company_name'];
    
    // Get news using web scraping
    $news = $webScraper->getStockNews($symbol, 5);
    
    if (!empty($news)) {
        foreach ($news as $article) {
            $title = $conn->real_escape_string($article['title']);
            $url = $conn->real_escape_string($article['url']);
            $source = $conn->real_escape_string($article['source']);
            $publishedAt = date('Y-m-d H:i:s', strtotime($article['published_date']));

            // Avoid duplicates
            $check = $conn->query("SELECT id FROM stock_news WHERE symbol = '$symbol' AND url = '$url'");
            if ($check->num_rows > 0) continue;

            $conn->query("INSERT INTO stock_news (symbol, title, url, source, published_at)
                          VALUES ('$symbol', '$title', '$url', '$source', '$publishedAt')");
        }
    }

    // Small delay to be respectful
    usleep(500000); // 0.5 seconds
}

echo "✅ News saved successfully using web scraping.";
?>
