<?php
header('Content-Type: application/json');

try {
    require_once '../includes/config.php';
    require_once '../includes/web_scraper.php';
    
    $symbol = isset($_GET['symbol']) ? trim($_GET['symbol']) : '';
    
    if (empty($symbol)) {
        echo json_encode(['error' => 'Symbol parameter is required']);
        exit;
    }
    
    // Use web scraping to get stock news
    global $webScraper;
    $news = $webScraper->getStockNews($symbol, 10);
    
    if (!empty($news)) {
        echo json_encode([
            'news' => $news,
            'source' => 'web_scraping',
            'note' => 'Data from web scraping'
        ]);
    } else {
        // Fallback to mock news if web scraping fails
        $mockNews = [
            [
                'title' => $symbol . ' Stock Market Update',
                'summary' => 'Latest developments and market analysis for ' . $symbol . '. Stay updated with the latest news and trends.',
                'url' => '#',
                'published_date' => date('Y-m-d'),
                'source' => 'Market News'
            ],
            [
                'title' => 'Analyst Report: ' . $symbol . ' Investment Outlook',
                'summary' => 'Financial analysts provide insights on future performance and investment recommendations.',
                'url' => '#',
                'published_date' => date('Y-m-d', strtotime('-1 day')),
                'source' => 'Financial Times'
            ],
            [
                'title' => $symbol . ' Quarterly Results Analysis',
                'summary' => 'Comprehensive analysis of the latest quarterly results and their impact on stock performance.',
                'url' => '#',
                'published_date' => date('Y-m-d', strtotime('-2 days')),
                'source' => 'Business Standard'
            ]
        ];
        
        echo json_encode([
            'news' => $mockNews,
            'source' => 'fallback',
            'note' => 'Fallback news. Web scraping may be unavailable.'
        ]);
    }
    
} catch (Exception $e) {
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
} catch (Error $e) {
    echo json_encode(['error' => 'Fatal error: ' . $e->getMessage()]);
}
?>
