<?php
header('Content-Type: application/json');

try {
    // Stock database with symbols and company names
    $stockDatabase = [
        // Adani Group Stocks
        'ADANIENT' => 'Adani Enterprises Limited',
        'ADANIPORTS' => 'Adani Ports and Special Economic Zone Limited',
        'ADANIPOWER' => 'Adani Power Limited',
        'ADANIGREEN' => 'Adani Green Energy Limited',
        'ADANITRANS' => 'Adani Transmission Limited',
        'ADANIGAS' => 'Adani Gas Limited',
        'ADANIWILMAR' => 'Adani Wilmar Limited',
        'ADANIONE' => 'Adani One Limited',
        
        // Tata Group Stocks
        'TATAMOTORS' => 'Tata Motors Limited',
        'TATASTEEL' => 'Tata Steel Limited',
        'TATACONSUM' => 'Tata Consumer Products Limited',
        'TATAPOWER' => 'Tata Power Company Limited',
        'TATACOMM' => 'Tata Communications Limited',
        'TATACHEM' => 'Tata Chemicals Limited',
        'TATACOMM' => 'Tata Communications Limited',
        'TCS' => 'Tata Consultancy Services Limited',
        
        // Reliance Group
        'RELIANCE' => 'Reliance Industries Limited',
        'JIOFIN' => 'Jio Financial Services Limited',
        
        // IT Companies
        'INFY' => 'Infosys Limited',
        'WIPRO' => 'Wipro Limited',
        'HCLTECH' => 'HCL Technologies Limited',
        'TECHM' => 'Tech Mahindra Limited',
        'MINDTREE' => 'Mindtree Limited',
        'LTI' => 'Larsen & Toubro Infotech Limited',
        
        // Banks
        'HDFC' => 'HDFC Bank Limited',
        'ICICIBANK' => 'ICICI Bank Limited',
        'SBIN' => 'State Bank of India',
        'KOTAKBANK' => 'Kotak Mahindra Bank Limited',
        'AXISBANK' => 'Axis Bank Limited',
        'INDUSINDBK' => 'IndusInd Bank Limited',
        'PNB' => 'Punjab National Bank',
        'CANBK' => 'Canara Bank',
        
        // FMCG
        'HINDUNILVR' => 'Hindustan Unilever Limited',
        'ITC' => 'ITC Limited',
        'NESTLEIND' => 'Nestle India Limited',
        'BRITANNIA' => 'Britannia Industries Limited',
        'MARICO' => 'Marico Limited',
        'DABUR' => 'Dabur India Limited',
        
        // Auto
        'MARUTI' => 'Maruti Suzuki India Limited',
        'TATAMOTORS' => 'Tata Motors Limited',
        'EICHERMOT' => 'Eicher Motors Limited',
        'HEROMOTOCO' => 'Hero MotoCorp Limited',
        'BAJAJ-AUTO' => 'Bajaj Auto Limited',
        'M&M' => 'Mahindra & Mahindra Limited',
        
        // Pharma
        'SUNPHARMA' => 'Sun Pharmaceutical Industries Limited',
        'DRREDDY' => 'Dr. Reddy\'s Laboratories Limited',
        'CIPLA' => 'Cipla Limited',
        'DIVISLAB' => 'Divi\'s Laboratories Limited',
        'BIOCON' => 'Biocon Limited',
        'APOLLOHOSP' => 'Apollo Hospitals Enterprise Limited',
        
        // US Stocks
        'AAPL' => 'Apple Inc.',
        'MSFT' => 'Microsoft Corporation',
        'GOOGL' => 'Alphabet Inc.',
        'AMZN' => 'Amazon.com Inc.',
        'TSLA' => 'Tesla Inc.',
        'META' => 'Meta Platforms Inc.',
        'NVDA' => 'NVIDIA Corporation',
        'NFLX' => 'Netflix Inc.',
        'ADBE' => 'Adobe Inc.',
        'CRM' => 'Salesforce Inc.',
        'JPM' => 'JPMorgan Chase & Co.',
        'JNJ' => 'Johnson & Johnson',
        'V' => 'Visa Inc.',
        'PG' => 'Procter & Gamble Co.',
        'HD' => 'The Home Depot Inc.',
        'DIS' => 'The Walt Disney Company',
        'PYPL' => 'PayPal Holdings Inc.',
        'INTC' => 'Intel Corporation',
        'AMD' => 'Advanced Micro Devices Inc.',
        'ORCL' => 'Oracle Corporation'
    ];
    
    $query = isset($_GET['q']) ? trim($_GET['q']) : '';
    
    if (empty($query)) {
        echo json_encode(['suggestions' => []]);
        exit;
    }
    
    $query = strtolower($query);
    $suggestions = [];
    
    foreach ($stockDatabase as $symbol => $company) {
        $symbolLower = strtolower($symbol);
        $companyLower = strtolower($company);
        
        // Check if query matches symbol or company name
        if (strpos($symbolLower, $query) !== false || 
            strpos($companyLower, $query) !== false ||
            strpos(str_replace([' ', '.', ',', 'limited', 'ltd', 'inc', 'corp'], '', $companyLower), $query) !== false) {
            
            $suggestions[] = [
                'symbol' => $symbol,
                'company' => $company,
                'display' => $symbol . ' - ' . $company
            ];
        }
    }
    
    // Sort by relevance (exact matches first, then partial matches)
    usort($suggestions, function($a, $b) use ($query) {
        $aSymbol = strtolower($a['symbol']);
        $bSymbol = strtolower($b['symbol']);
        $aCompany = strtolower($a['company']);
        $bCompany = strtolower($b['company']);
        
        // Exact symbol match gets highest priority
        if ($aSymbol === $query && $bSymbol !== $query) return -1;
        if ($bSymbol === $query && $aSymbol !== $query) return 1;
        
        // Symbol starts with query gets higher priority
        if (strpos($aSymbol, $query) === 0 && strpos($bSymbol, $query) !== 0) return -1;
        if (strpos($bSymbol, $query) === 0 && strpos($aSymbol, $query) !== 0) return 1;
        
        // Company name starts with query
        if (strpos($aCompany, $query) === 0 && strpos($bCompany, $query) !== 0) return -1;
        if (strpos($bCompany, $query) === 0 && strpos($aCompany, $query) !== 0) return 1;
        
        return strcmp($a['symbol'], $b['symbol']);
    });
    
    // Limit to top 10 suggestions
    $suggestions = array_slice($suggestions, 0, 10);
    
    echo json_encode(['suggestions' => $suggestions]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
}
?> 