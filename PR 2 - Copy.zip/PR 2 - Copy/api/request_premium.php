<?php
require_once '../includes/db_connect.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Authentication required.']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Update user status to 'pending'
$stmt = $conn->prepare("UPDATE users SET subscription_status = 'pending' WHERE id = ? AND subscription_status = 'free'");
$stmt->bind_param("i", $user_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(['success' => true, 'message' => 'Your request for premium access has been sent to the administrator for approval.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Could not process request. You may have already requested premium access.']);
    }
} else {
    http_response_code(500);
    echo json_encode(['error' => 'A server error occurred.']);
}

$stmt->close();
?>
