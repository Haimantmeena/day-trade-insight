<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1); // Display errors in output for debugging

// Set JSON header first
header('Content-Type: application/json');

try {
    require_once '../includes/config.php';
    require_once '../includes/web_scraper.php';
    
    $input = isset($_GET['symbol']) ? trim(strtoupper($_GET['symbol'])) : '';
    if (empty($input)) {
        http_response_code(400);
        echo json_encode(['error' => 'Stock symbol or company name is required.']);
        exit;
    }

    // --- Enhanced mapping with fuzzy search ---
    $symbolMap = [
        // Indian Stocks
        'TATAMOTORS' => 'Tata Motors Limited',
        'RELIANCE' => 'Reliance Industries Limited',
        'TCS' => 'Tata Consultancy Services Limited',
        'INFY' => 'Infosys Limited',
        'HDFC' => 'HDFC Bank Limited',
        'ICICIBANK' => 'ICICI Bank Limited',
        'HINDUNILVR' => 'Hindustan Unilever Limited',
        'ITC' => 'ITC Limited',
        'SBIN' => 'State Bank of India',
        'BHARTIARTL' => 'Bharti Airtel Limited',
        'KOTAKBANK' => 'Kotak Mahindra Bank Limited',
        'AXISBANK' => 'Axis Bank Limited',
        'ASIANPAINT' => 'Asian Paints Limited',
        'MARUTI' => 'Maruti Suzuki India Limited',
        'SUNPHARMA' => 'Sun Pharmaceutical Industries Limited',
        'TATAMOTORS' => 'Tata Motors Limited',
        'WIPRO' => 'Wipro Limited',
        'ULTRACEMCO' => 'UltraTech Cement Limited',
        'TITAN' => 'Titan Company Limited',
        'BAJFINANCE' => 'Bajaj Finance Limited',
        'NESTLEIND' => 'Nestle India Limited',
        'POWERGRID' => 'Power Grid Corporation of India Limited',
        'BAJAJFINSV' => 'Bajaj Finserv Limited',
        'NTPC' => 'NTPC Limited',
        'ONGC' => 'Oil and Natural Gas Corporation Limited',
        'COALINDIA' => 'Coal India Limited',
        'TECHM' => 'Tech Mahindra Limited',
        'ADANIPORTS' => 'Adani Ports and Special Economic Zone Limited',
        'HCLTECH' => 'HCL Technologies Limited',
        'JSWSTEEL' => 'JSW Steel Limited',
        'TATASTEEL' => 'Tata Steel Limited',
        'VEDL' => 'Vedanta Limited',
        'GRASIM' => 'Grasim Industries Limited',
        'EICHERMOT' => 'Eicher Motors Limited',
        'HEROMOTOCO' => 'Hero MotoCorp Limited',
        'DRREDDY' => 'Dr. Reddy\'s Laboratories Limited',
        'CIPLA' => 'Cipla Limited',
        'BRITANNIA' => 'Britannia Industries Limited',
        'SHREECEM' => 'Shree Cement Limited',
        'UPL' => 'UPL Limited',
        'ZEEL' => 'Zee Entertainment Enterprises Limited',
        'MM' => 'Mahindra & Mahindra Limited',
        'INFRATEL' => 'Bharti Infratel Limited',
        'INDUSINDBK' => 'IndusInd Bank Limited',
        'IOC' => 'Indian Oil Corporation Limited',
        'BPCL' => 'Bharat Petroleum Corporation Limited',
        'HINDALCO' => 'Hindalco Industries Limited',
        // US Stocks
        'AAPL' => 'Apple Inc.',
        'MSFT' => 'Microsoft Corporation',
        'GOOGL' => 'Alphabet Inc.',
        'AMZN' => 'Amazon.com Inc.',
        'TSLA' => 'Tesla Inc.',
        'META' => 'Meta Platforms Inc.',
        'NVDA' => 'NVIDIA Corporation',
        'NFLX' => 'Netflix Inc.',
        'ADBE' => 'Adobe Inc.',
        'CRM' => 'Salesforce Inc.',
        'JPM' => 'JPMorgan Chase & Co.',
        'JNJ' => 'Johnson & Johnson',
        'V' => 'Visa Inc.',
        'PG' => 'Procter & Gamble Co.',
        'HD' => 'The Home Depot Inc.'
    ];
    // Build a reverse map for fuzzy search
    $companyToSymbol = [];
    foreach ($symbolMap as $symbol => $company) {
        $companyToSymbol[strtoupper($company)] = $symbol;
    }
    $symbol = $input;
    $inputKey = str_replace([' ', '.', ',', 'LIMITED', 'LTD'], '', strtoupper($input));
    $bestMatch = null;
    $bestScore = 0;
    // 1. Exact symbol match
    if (isset($symbolMap[$input])) {
        $symbol = $input;
    } else {
        // 2. Fuzzy company name match
        foreach ($companyToSymbol as $companyName => $sym) {
            $companyKey = str_replace([' ', '.', ',', 'LIMITED', 'LTD'], '', $companyName);
            $score = 0;
            if (stripos($companyKey, $inputKey) !== false || stripos($inputKey, $companyKey) !== false) {
                $score += 80;
            }
            similar_text($inputKey, $companyKey, $percent);
            $score += $percent;
            if ($score > $bestScore) {
                $bestScore = $score;
                $bestMatch = $sym;
            }
        }
        // 3. Fuzzy symbol match
        foreach ($symbolMap as $sym => $companyName) {
            if (stripos($sym, $inputKey) !== false || stripos($inputKey, $sym) !== false) {
                $bestMatch = $sym;
                $bestScore = 100;
                break;
            }
        }
        if ($bestMatch && $bestScore > 60) {
            $symbol = $bestMatch;
        }
    }
    
    // Use enhanced web scraping with multiple fallbacks
    global $webScraper;
    $stockData = $webScraper->getEnhancedStockData($symbol);
    
    if ($stockData && !isset($stockData['error'])) {
        // Add compatibility fields
        $stockData['close_price'] = $stockData['price'];
        $stockData['price_change'] = $stockData['change'];
        if (!isset($stockData['open'])) $stockData['open'] = 'N/A';
        if (!isset($stockData['high'])) $stockData['high'] = 'N/A';
        if (!isset($stockData['low'])) $stockData['low'] = 'N/A';
        if (!isset($stockData['previous_close'])) $stockData['previous_close'] = 'N/A';
        if (!isset($stockData['founded_year'])) $stockData['founded_year'] = 'N/A';
        echo json_encode($stockData);
    } else {
        http_response_code(404);
        echo json_encode([
            'error' => 'Stock not found via web scraping. Please check the symbol or company name and try again.',
            'suggestion' => 'Try searching for popular stocks like TATAMOTORS, RELIANCE, TCS, AAPL, MSFT, ADANIPORTS, etc.'
        ]);
    }
    
} catch (Exception $e) {
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
} catch (Error $e) {
    echo json_encode(['error' => 'Fatal error: ' . $e->getMessage()]);
}
?>
