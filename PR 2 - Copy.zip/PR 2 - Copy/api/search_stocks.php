<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors in output, just log them

// Set JSON header first
header('Content-Type: application/json');

// Helper function to get fallback stocks
function getFallbackStocks($query) {
    $commonStocks = [
        ['symbol' => 'AAPL', 'name' => 'Apple Inc.'],
        ['symbol' => 'MSFT', 'name' => 'Microsoft Corporation'],
        ['symbol' => 'GOOGL', 'name' => 'Alphabet Inc.'],
        ['symbol' => 'AMZN', 'name' => 'Amazon.com Inc.'],
        ['symbol' => 'TSLA', 'name' => 'Tesla Inc.'],
        ['symbol' => 'META', 'name' => 'Meta Platforms Inc.'],
        ['symbol' => 'NVDA', 'name' => 'NVIDIA Corporation'],
        ['symbol' => 'NFLX', 'name' => 'Netflix Inc.'],
        ['symbol' => 'ADBE', 'name' => 'Adobe Inc.'],
        ['symbol' => 'CRM', 'name' => 'Salesforce Inc.']
    ];
    
    $results = [];
    $searchTerm = strtolower($query);
    
    // Filter by search query
    foreach ($commonStocks as $stock) {
        if (stripos($stock['symbol'], $searchTerm) !== false || stripos($stock['name'], $searchTerm) !== false) {
            $results[] = [
                'symbol' => $stock['symbol'],
                'name' => $stock['name'],
                'source' => 'fallback'
            ];
        }
    }
    
    // If still no results, return some common stocks
    if (empty($results)) {
        return [
            'error' => 'No results found. Try searching for: AAPL, MSFT, GOOGL, AMZN, TSLA',
            'suggestion' => 'For Indian stocks, try: RELIANCE, TCS, INFY, HDFC, ICICIBANK',
            'fallback_results' => array_slice($commonStocks, 0, 3)
        ];
    }
    
    return $results;
}

try {
    require_once '../includes/config.php';
    require_once '../includes/web_scraper.php';
    
    $query = isset($_GET['q']) ? trim($_GET['q']) : '';
    
    if (empty($query)) {
        echo json_encode([]);
        exit;
    }
    
    // Use web scraping to search for stocks
    global $webScraper;
    $results = $webScraper->searchStocks($query);
    
    // Log for debugging
    error_log("Search query: " . $query . ", Results count: " . count($results));
    
    if (!empty($results)) {
        echo json_encode($results);
        exit;
    }
    
    // If web scraping fails, try local database search
    $csvFile = __DIR__ . '/../ai/stock_data_csvs/stock_metadata.csv';
    $results = [];
    
    if (($handle = fopen($csvFile, 'r')) !== false) {
        $header = fgetcsv($handle); // skip header
        while (($row = fgetcsv($handle)) !== false) {
            $company_name = strtolower($row[0]);
            $csv_symbol = strtolower($row[2]);
            $search_term = strtolower($query);
            
            // Search in both company name and symbol
            if (strpos($company_name, $search_term) !== false || strpos($csv_symbol, $search_term) !== false) {
                $symbol = strtoupper($row[2]);
                
                // Try to get live data using web scraping
                $stockData = $webScraper->getStockData($symbol);
                
                $close_price = 'N/A';
                $price_change = 'N/A';
                $market_cap = 'N/A';
                $date = 'N/A';
                $founded_year = 'N/A';
                
                if ($stockData) {
                    $close_price = $stockData['price'];
                    $price_change = $stockData['change'];
                    $market_cap = $stockData['market_cap'];
                    $date = $stockData['last_refreshed'];
                }
                
                $results[] = [
                    'symbol' => $symbol,
                    'company_name' => $row[0],
                    'industry' => $row[1],
                    'series' => $row[3],
                    'isin_code' => $row[4],
                    'close_price' => $close_price,
                    'price' => $close_price,
                    'price_change' => $price_change,
                    'change' => $price_change,
                    'change_percent' => 'N/A',
                    'open' => 'N/A',
                    'high' => 'N/A',
                    'low' => 'N/A',
                    'volume' => 'N/A',
                    'market_cap' => $market_cap,
                    'founded_year' => $founded_year,
                    'date' => $date,
                    'last_refreshed' => $date,
                    'source' => 'database'
                ];
            }
        }
        fclose($handle);
    }
    
    if (!empty($results)) {
        echo json_encode($results);
        exit;
    }
    
    // If no results found, provide fallback data
    $fallbackResults = getFallbackStocks($query);
    if (is_array($fallbackResults) && !empty($fallbackResults)) {
        echo json_encode($fallbackResults);
    } else {
        echo json_encode([]);
    }
    
} catch (Exception $e) {
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
} catch (Error $e) {
    echo json_encode(['error' => 'Fatal error: ' . $e->getMessage()]);
}
?>
