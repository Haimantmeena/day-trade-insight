<?php
require_once '../includes/config.php';
require_once '../includes/web_scraper.php';

$symbol = 'TCS';

$webScraper = new WebScraper();
$query = urlencode($symbol . " stock price");
$url = "https://www.google.com/search?q=" . $query;
$html = $webScraper->fetchUrl($url);

if ($html) {
    file_put_contents(__DIR__ . "/google_search_{$symbol}.html", $html);
    echo "Google search HTML saved to google_search_{$symbol}.html\n";
} else {
    echo "Failed to fetch Google search page for symbol: {$symbol}\n";
}
?>
