<?php
// Test file to debug web scraping issues
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../includes/config.php';
require_once '../includes/web_scraper.php';

echo "<h2>🔍 Web Scraping Test Results</h2>";

$symbols = ['TCS', 'RELIANCE', 'INFY', 'AAPL', 'MSFT'];
$webScraper = new WebScraper();

foreach ($symbols as $symbol) {
    echo "<hr><h3>Testing: $symbol</h3>";
    
    // Test 1: Yahoo Finance
    echo "<h4>1. Yahoo Finance Test:</h4>";
    $yahooData = $webScraper->getStockData($symbol);
    if ($yahooData) {
        echo "<div style='background: #d4edda; padding: 10px; margin: 5px; border-radius: 5px;'>";
        echo "<strong>✅ SUCCESS:</strong><br>";
        echo "Price: " . $yahooData['price'] . "<br>";
        echo "Change: " . $yahooData['change'] . "<br>";
        echo "Open: " . $yahooData['open'] . "<br>";
        echo "High: " . $yahooData['high'] . "<br>";
        echo "Low: " . $yahooData['low'] . "<br>";
        echo "Volume: " . $yahooData['volume'] . "<br>";
        echo "Source: " . $yahooData['source'] . "<br>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; padding: 10px; margin: 5px; border-radius: 5px;'>";
        echo "<strong>❌ FAILED:</strong> Yahoo Finance scraping failed<br>";
        echo "</div>";
    }
    
    // Test 2: Google Search
    echo "<h4>2. Google Search Test:</h4>";
    $googleData = $webScraper->getGoogleSearchStockData($symbol);
    if ($googleData && !isset($googleData['error'])) {
        echo "<div style='background: #d4edda; padding: 10px; margin: 5px; border-radius: 5px;'>";
        echo "<strong>✅ SUCCESS:</strong><br>";
        echo "Price: " . $googleData['price'] . "<br>";
        echo "Change: " . $googleData['change'] . "<br>";
        echo "Source: " . $googleData['source'] . "<br>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; padding: 10px; margin: 5px; border-radius: 5px;'>";
        echo "<strong>❌ FAILED:</strong> Google search scraping failed<br>";
        if (isset($googleData['error'])) {
            echo "Error: " . $googleData['error'] . "<br>";
        }
        echo "</div>";
    }
    
    // Test 3: MoneyControl (for Indian stocks)
    if (strlen($symbol) > 3) {
        echo "<h4>3. MoneyControl Test:</h4>";
        $moneyData = $webScraper->getMoneyControlData($symbol);
        if ($moneyData) {
            echo "<div style='background: #d4edda; padding: 10px; margin: 5px; border-radius: 5px;'>";
            echo "<strong>✅ SUCCESS:</strong><br>";
            echo "Price: " . $moneyData['price'] . "<br>";
            echo "Source: " . $moneyData['source'] . "<br>";
            echo "</div>";
        } else {
            echo "<div style='background: #f8d7da; padding: 10px; margin: 5px; border-radius: 5px;'>";
            echo "<strong>❌ FAILED:</strong> MoneyControl scraping failed<br>";
            echo "</div>";
        }
    }
    
    echo "<br>";
}

// Test URL fetching directly
echo "<hr><h3>🔧 URL Fetching Test</h3>";
$testUrls = [
    'Yahoo Finance TCS' => 'https://query1.finance.yahoo.com/v8/finance/chart/TCS.NS',
    'Yahoo Finance AAPL' => 'https://query1.finance.yahoo.com/v8/finance/chart/AAPL',
    'Google Search TCS' => 'https://www.google.com/search?q=TCS+stock+price'
];

foreach ($testUrls as $name => $url) {
    echo "<h4>Testing: $name</h4>";
    $response = $webScraper->fetchUrl($url);
    if ($response) {
        echo "<div style='background: #d4edda; padding: 10px; margin: 5px; border-radius: 5px;'>";
        echo "<strong>✅ SUCCESS:</strong> URL fetched successfully<br>";
        echo "Response length: " . strlen($response) . " characters<br>";
        echo "First 200 chars: " . htmlspecialchars(substr($response, 0, 200)) . "...<br>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; padding: 10px; margin: 5px; border-radius: 5px;'>";
        echo "<strong>❌ FAILED:</strong> URL fetch failed<br>";
        echo "</div>";
    }
}

echo "<hr><h3>📊 Summary</h3>";
echo "<p>This test shows which scraping methods are working and which are failing.</p>";
echo "<p>If most methods are failing, it could be due to:</p>";
echo "<ul>";
echo "<li>Network connectivity issues</li>";
echo "<li>Websites blocking automated requests</li>";
echo "<li>Changes in website structure</li>";
echo "<li>Firewall or proxy settings</li>";
echo "</ul>";
?> 