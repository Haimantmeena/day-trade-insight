# ai/create_training_data.py
import pandas as pd
import os
from tqdm import tqdm
import warnings

warnings.filterwarnings('ignore', category=FutureWarning)

# The folder where you have placed all your individual stock CSV files.
DATA_SOURCE_FOLDER = 'stock_data_csvs'

# --- Main Script ---
script_dir = os.path.dirname(__file__)
data_folder_path = os.path.join(script_dir, DATA_SOURCE_FOLDER)

if not os.path.isdir(data_folder_path):
    print(f"\nFATAL: Folder '{DATA_SOURCE_FOLDER}' not found in the 'ai' directory!")
    print("Please create this folder and place all your company CSV files inside it.")
    exit()

all_files = [f for f in os.listdir(data_folder_path) if f.endswith('.csv')]

if not all_files:
    print(f"\nFATAL: No CSV files found in the '{DATA_SOURCE_FOLDER}' folder.")
    exit()

print(f"Found {len(all_files)} CSV files. Starting data processing...")

all_stocks_data = []

for file_name in tqdm(all_files, desc="Reading CSV Files"):
    try:
        file_path = os.path.join(data_folder_path, file_name)
        # Read the CSV file
        df = pd.read_csv(file_path)
        
        required_columns = ['Date', 'Open', 'High', 'Low', 'Close', 'Volume']
        if not all(col in df.columns for col in required_columns):
            tqdm.write(f"Warning: Skipping '{file_name}' because it's missing a required column. Needed: {required_columns}")
            continue

        df['Symbol'] = os.path.splitext(file_name)[0]
        all_stocks_data.append(df)
    except Exception as e:
        tqdm.write(f"Warning: Failed to process '{file_name}'. Error: {e}")

if not all_stocks_data:
    print("\nFATAL: Could not process any CSV files. Please check their format.")
    exit()

print("\nCombining all data into a single dataset...")
combined_data = pd.concat(all_stocks_data, ignore_index=True)

combined_data['Date'] = pd.to_datetime(combined_data['Date'])
combined_data.sort_values(by=['Symbol', 'Date'], inplace=True)

print("Calculating technical indicators (SMA, RSI)...")
def calculate_features(df):
    df['SMA_20'] = df['Close'].rolling(window=20).mean()
    df['SMA_50'] = df['Close'].rolling(window=50).mean()
    delta = df['Close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss.replace(0, 1e-9)
    df['RSI'] = 100 - (100 / (1 + rs))
    return df

tqdm.pandas(desc="Calculating Features")
processed_data = combined_data.groupby('Symbol').progress_apply(calculate_features)

print("Creating the target variable for prediction...")

# FIXED HERE ✅✅
processed_data = processed_data.reset_index(drop=True)

processed_data['Future_Close'] = processed_data.groupby('Symbol')['Close'].shift(-5)
processed_data['Target'] = (processed_data['Future_Close'] > processed_data['Close']).astype(int)

processed_data.dropna(inplace=True)

output_filename = 'master_training_data.csv'
try:
    processed_data.to_csv(os.path.join(script_dir, output_filename), index=False)
    print(f"\n✅ Successfully created master training data file: '{output_filename}'")
    print("This file combines and prepares all your CSV data.")
    print("You can now run 'train_model.py'.")
except Exception as e:
    print(f"\nFATAL: Could not save the data to CSV. Error: {e}")
