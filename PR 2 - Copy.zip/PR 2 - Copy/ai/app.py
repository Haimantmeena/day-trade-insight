# ai/app.py
from flask import Flask, request, jsonify
from flask_cors import CORS
from prediction_model import predictor
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

app = Flask(__name__)
CORS(app)

# ROUTE 1: For LIVE analysis from the search page
@app.route('/predict_live', methods=['GET'])
def predict_live_endpoint():
    symbol = request.args.get('symbol')
    if not symbol:
        return jsonify({"error": "Symbol parameter is required for live prediction."}), 400
    try:
        prediction = predictor.predict_with_live_data(symbol)
        return jsonify(prediction)
    except Exception as e:
        app.logger.error(f"LIVE prediction failed for {symbol}: {e}", exc_info=True)
        return jsonify({"error": str(e)}), 500

# ROUTE 2: For OFFLINE analysis from the stock list page
@app.route('/predict_offline', methods=['GET'])
def predict_offline_endpoint():
    try:
        close_price = request.args.get('close_price')
        price_change = request.args.get('price_change')
        market_cap = request.args.get('market_cap')

        # Parameter Validation
        if close_price is None or price_change is None or market_cap is None:
            return jsonify({"error": "Missing one or more required parameters: close_price, price_change, market_cap"}), 400

        # Convert to float
        close_price = float(close_price)
        price_change = float(price_change)
        market_cap = float(market_cap)

        prediction = predictor.predict_with_db_data(close_price, price_change, market_cap)
        return jsonify(prediction)
    except Exception as e:
        app.logger.error(f"OFFLINE prediction failed: {e}", exc_info=True)
        return jsonify({"error": "Offline analysis failed."}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)  # Debug True rakha for error detail
# ai/app.py
from flask import Flask, request, jsonify
from flask_cors import CORS
from prediction_model import predictor
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

app = Flask(__name__)
CORS(app)

# ROUTE 1: For LIVE analysis from the search page
@app.route('/predict_live', methods=['GET'])
def predict_live_endpoint():
    symbol = request.args.get('symbol')
    if not symbol:
        return jsonify({"error": "Symbol parameter is required for live prediction."}), 400
    try:
        prediction = predictor.predict_with_live_data(symbol)
        return jsonify(prediction)
    except Exception as e:
        app.logger.error(f"LIVE prediction failed for {symbol}: {e}", exc_info=True)
        return jsonify({"error": str(e)}), 500

# ROUTE 2: For OFFLINE analysis from the stock list page
@app.route('/predict_offline', methods=['GET'])
def predict_offline_endpoint():
    try:
        close_price = request.args.get('close_price')
        price_change = request.args.get('price_change')
        market_cap = request.args.get('market_cap')

        # Parameter Validation
        if close_price is None or price_change is None or market_cap is None:
            return jsonify({"error": "Missing one or more required parameters: close_price, price_change, market_cap"}), 400

        # Convert to float

        
        close_price = float(close_price)
        price_change = float(price_change)
        market_cap = float(market_cap)
        prediction = predictor.predict_with_db_data(close_price, price_change, market_cap)
        return jsonify(prediction)
    except Exception as e:
        app.logger.error(f"OFFLINE prediction failed: {e}", exc_info=True)
        return jsonify({"error": "Offline analysis failed."}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)  # Debug True rakha for error detail
