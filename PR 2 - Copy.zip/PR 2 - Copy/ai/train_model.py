# ai/train_model.py
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from joblib import dump
from tqdm import tqdm
import warnings
import os

warnings.filterwarnings('ignore', category=FutureWarning)

# --- This script uses the master file created by 'create_training_data.py' ---
TRAINING_DATA_FILE = 'master_training_data.csv' 

total_steps = 3
with tqdm(total=total_steps, desc="AI Model Training from Your CSVs") as pbar:

    pbar.set_description(f"Step 1/3: Loading data from '{TRAINING_DATA_FILE}'")
    try:
        script_dir = os.path.dirname(__file__)
        csv_path = os.path.join(script_dir, TRAINING_DATA_FILE)
        data = pd.read_csv(csv_path)
        pbar.update(1)
    except FileNotFoundError:
        print(f"\nFATAL: File '{TRAINING_DATA_FILE}' not found in the 'ai' folder!")
        print("Please run 'python create_training_data.py' first to generate it.")
        exit()
    except Exception as e:
        print(f"\nFATAL: Could not read CSV file. Error: {e}")
        exit()

    pbar.set_description("Step 2/3: Preparing Features & Target")
    try:
        features = ['SMA_20', 'SMA_50', 'RSI', 'Volume']
        X = data[features]
        y = data['Target']
        pbar.update(1)
    except KeyError as e:
        print(f"\nFATAL: Missing required column in your CSV file: {e}")
        print("Please make sure your master CSV was created correctly.")
        exit()

    if len(X) == 0: 
        print("\nFATAL: No data available for training in the CSV file.")
        exit()

    # Step 3: Split data, train model, calculate metrics
    pbar.set_description(f"Step 3/3: Training model on {len(X)} data points")
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestClassifier(
        n_estimators=150,
        min_samples_leaf=10,
        random_state=42,
        n_jobs=-1,
        class_weight='balanced'
    )
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    # Metrics
    print("\n=== Model Performance Metrics ===")
    print("Accuracy:", accuracy_score(y_test, y_pred))
    print("Precision:", precision_score(y_test, y_pred, zero_division=0))
    print("Recall:", recall_score(y_test, y_pred, zero_division=0))
    print("F1 Score:", f1_score(y_test, y_pred, zero_division=0))
    print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))

    pbar.update(1)

# Save the final model
dump(model, os.path.join(script_dir, 'stock_predictor_model.joblib'))
print(f"\n✅ AI Model training complete using your data from '{TRAINING_DATA_FILE}'.")
print("The new model is saved as 'stock_predictor_model.joblib'.")
print("You can now run 'python app.py' to start the server.")
